#include<stdio.h>
void abc(char *p)
{
printf("in m1 %s\n",p);
}
