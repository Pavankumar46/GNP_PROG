#include<stdio.h>
main()
{
abc("hello world");
}
