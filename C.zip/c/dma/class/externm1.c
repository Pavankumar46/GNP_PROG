#include<stdio.h>
extern int i;
main()
{
printf("%d",i);
}

