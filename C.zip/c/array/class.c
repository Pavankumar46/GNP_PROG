/*#include<stdio.h>
main()
{
int a[5]={1,2,3,4,5};
char *p;
int i;
p=a;
for(i=0;i<5;i++)
printf("%d ",*p++);
}*/


/*#include<stdio.h>
main()
{
int a[5]={1,2,3,4,5};
int i,*p;
p=a+2;
printf("%d ",p[1]);
}*/


//copying one array to another
/*#include<stdio.h>
main()
{
int a[5]={1,2,3,4,5},b[5],i;
for(i=0;i<5;i++)
{
b[i]=a[i];
printf("%d",b[i]);
}
printf("\n");
}*/

//Reverse copying of one array into another array
/*#include<stdio.h>
main()
{
int a[5]={1,2,3,4,5},b[5],i=0,j;
for(j=4;j>=0;j--)
{
b[i]=a[j];
printf("%d ",b[i]);
i++;
}
printf("\n");
}*/


//character array and string
/*#include<stdio.h>
main()
{
char a[]={'a','b','c','d'};
char s[]="pavan";
printf("%d %d %s ",sizeof(a),sizeof(s),s);
}*/

/*#include<stdio.h>
main()
{
char s[10];
printf("enter the string\n");
scanf("%s",s);
printf("s=%s\n",s);
}*/

/*#include<stdio.h>
main()
{
char s[10];
printf("enter the number\n");
scanf("%s",s);
printf("s+1=%s\n",s+1);
}*/

/*#include<stdio.h>
main()
{
char s[30];
printf("enter the number\n");
//scanf("%s",s);
////scanf("%[^\n]",s);
gets(s);
////printf("%s ",s);
puts(s);
}*/

/*#include<stdio.h>
main()
{
char s[30];
printf("enter the number\n");
scanf("%[^@]",s);
printf("%s\n",s);
}*/

//printing the string char by char
/*#include<stdio.h>
main()
{
char s[10];int i;
printf("enter the string\n");
scanf("%s",s);
for(i=0;s[i]!='\0';i++)
for(i=0;s[i];i++)
printf("%c\n",s[i]);
}*/

//counting a particularr char in a given string
/*#include<stdio.h>
main()
{
	char s[10];
	char ch;
	int i,c=0;
	printf("enter the char\n");
	scanf("%c",&ch);
	printf("enter the string\n");
	scanf("%s",s);
	for(i=0;s[i];i++)
		if(s[i]==ch)
			c++;
	printf("%d",c);
}*/

//replacing a 2nd char with first char in a string
/*#include<stdio.h>
main()
{
	char a,b;
	char s[10];
	int i;
	printf("enter the two char\n");
	scanf("%c %c",&a,&b);
  	printf("enter the string\n");
	scanf("%s",s);
	for(i=0;s[i];i++)	
		if(s[i]==a)
			s[i]=b;
	printf("%s",s);
}*/


//bubble sort using arrays
#include<stdio.h>
main()
{
	char s[5],i,j,temp;
	int l;
	printf("enter the string\n");
	scanf("%s",s);
	for(l=0;s[l];l++);
	for(i=0;i<l-1;i++)
		for(j=0;j<l-1-i;j++)
			if(s[j]>s[j+1])
			{ 
				temp=s[j];
				s[j]=s[j+1];
				s[j+1]=temp;
			}
	/*for(i=0;s[i];i++)
		printf("%c",s[i]);
	printf("\n");*/
	printf("%s\n",s);
}









