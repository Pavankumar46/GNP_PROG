//size 
/*#include<stdio.h>
main()
{
int b[2][3]={1,2,3,4,5,6};
printf("%d %d %d\n",sizeof b,sizeof b[0],sizeof b[0][0]);
}*/

//finding rows & coloumns
/*#include<stdio.h>
main()
{
int r,c,i,j,b[2][3]={1,2,3,4,5,6};
r=sizeof b/sizeof b[0];
c=sizeof b[0]/sizeof b[0][0];
for(i=0;i<r;i++)
{
for(j=0;j<c;j++)
printf("%d ",b[i][j]);
}
}*/

//scan and print the array
/*#include<stdio.h>
main()
{
	int r,c,i,j,b[2][3];
	r=sizeof b/sizeof b[0];
	c=sizeof b[0]/sizeof b[0][0];
	printf("enter the elements\n");
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
			scanf("%d",&b[i][j]);
	}
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
			printf("%d ",b[i][j]);
		printf("\n");
	}
}*/

//sizes of different forms
/*#include<stdio.h>
main()
{
	int r,c,i,j,b[2][3];
	r=sizeof b/sizeof b[0];
	c=sizeof b[0]/sizeof b[0][0];
	printf("enter the elements\n");
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
			scanf("%d",&b[i][j]);
	}

	printf("b=%u\t\tb+1=%u\n",b,b+1);
	printf("&b=%u\t\t&b+1=%u\n",&b,&b+1);
	printf("b[0]=%u\t\tb[0]+1=%u\n",b[0],b[0]+1);
	printf("b[0][0]=%u\t\tb[0][0]+1=%u\n",b[0][0],b[0][0]+1);
	printf("&b[0]=%u\t&b[0]+1=%u\n",&b[0],&b[0]+1);
	printf("&b[0][0]=%u\t&b[0][0]+1=%u\n\n\n",&b[0][0],&b[0][0]+1);
	printf("**b+1 or b[0][0]+1 or *(*(b+0)+0)=%u\n",**b+1);
//	printf("**b+1 or b[0][0]+1 or *(*(b+0)+0)=%d\n",**b+1);
	printf("*(*b+1) or *(b[0]+1) or b[0][1] or *(*(b+0)+1)=%u\n",*(*b+1));
//	printf("*(*b+1) or *(b[0]+1) or b[0][1] or *(*(b+0)+1)=%d\n",*(*b+1));
}*/


