/*#include<stdio.h>
main()
{
int a[5];
printf("%d",sizeof a);
}*/

/*#include<stdio.h>
main()
{
int i,ele,a[5]={10,20,30,40,50};
ele=sizeof a/sizeof a[0];
printf("%d ",sizeof a);
printf("%d ",sizeof a[0]);
printf("%d ",ele);
for(i=0;i<ele;i++)
printf("%d  ",a[i]);
printf("\n");
}*/

/*#include<stdio.h>
main()
{
int ele,i,a[5];
ele=sizeof (a)/sizeof a[0];
for(i=0;i<ele;i++)
printf("%p\n",&a[i]);
printf("enter the elements\n");
for(i=0;i<ele;i++)
scanf("%d",&a[i]);
printf("\n");
for(i=0;i<ele;i++)
printf("%d ",a[i]);
printf("\n");
}*/

/*#include<stdio.h>
main()
{
int j,ele,t,i,a[10];
ele=sizeof a/sizeof a[0];
printf("enter the number\n");
for(i=0;i<ele;i++)
scanf("%d",&a[i]);
printf("\n");
for(i=0;i<ele;i++)
printf("%d ",a[i]);
printf("\n");
for(i=0,j=ele-1;i<j;i++,j--)
{
t=a[i];
a[i]=a[j];
a[j]=t;
}
for(i=0;i<ele;i++)
printf("%d ",a[i]);
printf("\n");
}*/


/*#include<stdio.h>
main()
{
int c,ele,a[5],i,j;
printf("enter the elements\n:");
ele=sizeof a/sizeof a[0];
for(i=0;i<ele;i++)
scanf("%d",&a[i]);
for(i=0,c=0;i<ele;i++)
{
 for(j=2;j<a[i];j++)
{
 if(a[i]%j==0)
break;
}
if(a[i]==j)
{
c++;
printf("%d ",a[i]);
}
}
printf("c=%d\n",c);
}*/

/*#include<stdio.h>
main()
{
int t,ele,a[10],i,j;
ele=sizeof a/sizeof a[0];
printf("enter the elements\n");
for(i=0;i<ele;i++)
scanf("%d",&a[i]);
for(i=0,j=1;i<ele-1 && j<ele;i+=2,j+=2)
{
t=a[i];
a[i]=a[j];
a[j]=t;
}
for(i=0;i<ele;i++)
printf("%d ",a[i]);
printf("\n");
}*/


//Armstrong number using arrays

/*#include<stdio.h>
main()
{
int ele,a[10],i,b,c,s,r,l,k;
ele=sizeof a/sizeof a[0];
printf("enter the elements\n");
for(i=0;i<ele;i++)
scanf("%d",&a[i]);
for(i=0;i<ele;i++)
{
b=a[i];
 for(c=0;b!=0;c++)
{ 
b=b/10;
}
b=a[i];
 for(s=0;b!=0;b/=10)
{
  r=b%10;
   for(l=1,k=1;l<=c;l++)
     k=k*r;
  s+=k;
}
if(s==a[i])
{
printf("%d ",s);
}
}
}*/

//perfect number using arrays

/*#include<stdio.h>
main()
{
	int ele,a[5],i,s,j;
	ele=sizeof a/sizeof a[0];
	printf("enter the elements\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);
	for(i=0;i<ele;i++)
	{
		s=0;
		for(j=1;j<a[i];j++)
		{
			if(a[i]%j==0)
				s=s+j;
		}	
		if(s==a[i])
			printf("%d ",s);
	}
}*/
  
//example

/*#include<stdio.h>
main()
{
int a[5]={10,20,30,40,50};
printf("%u %u\n",a,&a);
printf("%u %u\n",a+1,&a+1);
}*/

//example

/*#include<stdio.h>
main()
{
int a[5]={1,2,3,4,5},i;
for(i=0;i<5;i++)
printf("%d %d %d\n",a[i],i[a],*(a+i));
}*/


//decimal to binary conversion

/*#include<stdio.h>
main()
{
	int num,a[15],i,j;
	printf("enter a decimal nnumber\n");
	scanf("%d",&num);
	i=0;
	while(num>0)
	{
		a[i]=num%2;
		num/=2;
		i++;
	}
	printf("binary number is:\n");
	for(j=i-1;j>=0;j--)
		printf("%d",a[j]);
	printf("\n");
}*/

//matrix using array

/*#include<stdio.h>
main()
{
	int a[10][10],r,c,i,j;
	printf("enter the elements\n");
	scanf("%d %d",&r,&c);
	for(i=0;i<r;i++)
		for(j=0;j<c;j++)
			scanf("%d",&a[i][j]);
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
			printf("%5d",a[i][j]);
		printf("\n");
	}
}*/

//addition of matrices

/*#include<stdio.h>
main()
{
	int a[10][10],r,c,i,b[10][10],j;
	printf("enter the elements\n");
	scanf("%d %d",&r,&c);
	printf("first matrix\n");
	for(i=0;i<r;i++)
		for(j=0;j<c;j++)
			scanf("%d",&a[i][j]);
	printf("second matrix\n");
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
			scanf("%d",&b[i][j]);
	
	}
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
			printf("%d ",a[i][j]+b[i][j]);
		printf("\n");
	}

}*/
//mul of matrices using arrays
#include<stdio.h>
int main(void)
{
	int mat1[10][10],mat2[10][10],mat3[10][10],ROW1,ROW2,COL1,COL2;
	int i,j,k;
	printf("Enter matrix mat1row-wise :\n");
	scanf("%d %d",&ROW1,&COL1);
	for(i=0; i<ROW1; i++)
		for(j=0; j<COL1; j++)
			scanf("%d",&mat1[i][j]);
	printf("Enter matrix mat2row-wise :\n");
	scanf("%d %d",&ROW2,&COL2);
	for(i=0; i<ROW2; i++)
		for(j=0; j<COL2; j++)
			scanf("%d",&mat2[i][j] );
	/*Multiplication*/
	for(i=0; i<ROW1; i++)
		for(j=0; j<COL2; j++)
		{
			mat3[i][j] = 0;
			for(k=0; k<COL1; k++)
				mat3[i][j] += mat1[i][k] * mat2[k][j];
		}
	printf("The Resultant matrix mat3 is :\n");
	for(i=0; i<ROW1; i++)
	{
		for(j=0; j<COL2; j++)
			printf("%5d",mat3[i][j]);
		printf("\n");
	}




}


