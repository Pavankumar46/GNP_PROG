//1 add even,product odd
/*#include<stdio.h>
  main()
  {
  int a[10],i,s=0,p=1,ele;
  ele=sizeof a/sizeof a[0];
  printf("Enter the numbers\n");
  for(i=0;i<ele;i++)
  scanf("%d",&a[i]);
  for(i=0;i<ele;i++)
  {
  if(i%2==0)
  s+=i;
  else
  p*=i;
  }
  printf("add even=%d, product odd=%d\n",s,p);
  }*/

//biggest and smallest
/*#include<stdio.h>
main()
{
	int a[10],big,small,ele,index1=0,index2=0,i,j;
	ele=sizeof a/sizeof a[0];
	printf("Enter the numbers\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);
	big=a[0];
	small=a[0];
	for(i=0;i<ele;i++)
	{
		if(a[i]>big)
		{
			big=a[i];
			index1=i;
		}
		if(a[i]<small)
		{
			small=a[i];
			index2=i;
		}
	}
	printf("big=%d, small=%d, index1=%d, index2=%d\n",big,small,index1,index2);
}*/

//counting prime numbers and storing in another array
/*#include<stdio.h>
main()
{
	int a[10],b[10],k=0,j,i,c=0,ele;
	ele=sizeof a/sizeof a[0];
	printf("Enter the numbers\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);
	for(j=0;j<ele;j++)
	{
		for(i=2;i<a[j];i++)
		{
			if(a[j]%i==0)
				break;
		}
		if(a[j]==i)
		{
			c++;
			b[k]=a[j]; 
			k++;
		}
  	
	}
	printf("count=%d\n",c);
	for(i=0;i<k;i++)
		printf("%d ",b[i]);
}*/

//second largest and second smallest numbers
/*#include<stdio.h>
main()
{
	int a[10],i,ele,j,l,sl,s,ss;
	ele=sizeof a/sizeof a[0];
	printf("enter the number\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);
	if(a[0]>a[1])
	{
		l=a[0];
		sl=a[1];
	}
	else
	{
		l=a[1];
		sl=a[0];
	}
	if(a[0]<a[1])
	{
		s=a[0];
		ss=a[1];
	}
	else
	{	
		s=a[1];
		ss=a[0];
	}
	for(i=2;i<ele;i++)
	{
		if(a[i]>l)
		{
			sl=l;
			l=a[i];
		}
		else if(a[i]>sl)
			sl=a[i];
		if(a[i]<s)
		{
			ss=s;
			s=a[i];
		}
		else if(a[i]<ss)
			ss=a[i];
	}
	printf("l=%d, sl=%d, s=%d, ss=%d\n",l,sl,s,ss);
}*/

//reverse the elements of a given number
/*#include<stdio.h>
main()
{
	int a[5],ele,i,j,temp;
	ele=sizeof a/sizeof a[0];
	printf("enter the elements\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);
	for(i=0,j=4;i<j;i++,j--)
	{
		temp=a[i];
		a[i]=a[j];
		a[j]=temp;
	}
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
}*/

//delete an element at desired position from an array
/*#include<stdio.h>
main()
{
	int a[8],i,ele,n,p;
	ele=sizeof a/sizeof a[0];
	printf("enter the element\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);
	printf("enter the position\n");
	scanf("%d",&p);
	printf("leaving an empty space\n");
	for(i=0;i<ele;i++)
	{
		if(i==p-1)
		{
			printf("\n"); 
			i++;
		} 
		printf("%d\n",a[i]);
	}
	printf("array after deletion\n");
	for(i=0;i<ele;i++)
	{
		if(i>=p-1)
			a[i]=a[i+1];
	}
	for(i=0;i<ele;i++)
	{
		if(i>=ele-1)
			printf("\n");
		else
			printf("%d\n",a[i]);
	}
}*/

//insert an element in an array
/*#include<stdio.h>
main()
{
	char a[10]={'b','c','d','e','f'},ch;
	int i,j,p;
	for(i=0;a[i]!='\0';i++)
		printf("%c ",a[i]);
	printf("\n");
	printf("enter the char and position\n");
	scanf("%c",&ch);
	printf("enter the position\n");
	scanf(" %d",&p);
	for(i=5;i>=0;i--)
	{
	if(i==p)
	{
	for(j=5;j>=i;j--)
	a[j]=a[j-1];
	a[j]=ch;
	break;
	}
	}
	for(i=0;a[i]!='\0';i++)
		printf("%c ",a[i]);
		}*/

//delete duplicate elements in an array
//method 1
/*#include<stdio.h>
main()
{
	char a[]={'a','c','b','d','a','b','e','d','b','c'};
	int ele,i,j,k;
	ele=sizeof a/sizeof a[0];
	for(i=0;i<ele;i++)
	{
		for(j=i+1;j<ele;j++)
		{
			if(a[i]==a[j])
			{
				for(k=j;k<ele;k++)
					a[k]=a[k+1];
				ele--;
			}
		}
	}
for(i=0;i<ele;i++)
printf("%c ",a[i]);
printf("\n");
}*/

//method 2
//removing duplicate eliments
/*#include<stdio.h>
main()
{
	int t,k,i,j,ele,c,b,a[]={0,3,1,0,5,1,2,0,4,5};
	ele=sizeof a/sizeof a[0];
	for(i=0;i<ele;i++)
	{
		c=1;
		for(j=0;j<ele;j++)
		{
			if(a[i]==a[j]);
			{
			continue;
			}
		}
		for(k=i+1;k<ele;k++)
		{
			if(a[i]==a[k])
			c++;	
		}
	if(c==1)
	printf("%d ",a[i]);
	}
}*/

					

// 9) count of the duplicate elements
/*#include<stdio.h>
main()
{
	int t,i,j,ele,c,b,a[]={0,3,1,0,5,1,2,0,4,5};
	ele=sizeof a/sizeof a[0];
	for(i=0;i<ele-1;i++)
	{
		for(j=0;j<ele-1-i;j++)
		{
			if(a[j]>a[j+1])
			{
				t=a[j];
				a[j]=a[j+1];
				a[j+1]=t;
			}
		}
	}
	for(i=0;i<ele;i=j)
	{
		c=1;
		for(j=i+1;j<ele;j++)
		{
			if(a[i]==a[j])
			{
				b=a[i];
				c++;
			}
			else
				break;	
		}
		if(c>1)
			printf("%d %d\n",b,c);
	}
}*/

//print the non repeated numbers in an array
//method 1
/*#include<stdio.h>
main()
{
	int i,ele,j,k,c,a[]={0,3,1,0,5,1,2,0,4,5};
	ele=sizeof a/sizeof a[0];
	for(i=0;i<ele;i++)
	{c=0;
		for(j=i+1;j<ele;j++)
		{
			if(a[i]==a[j])
			{
				c++;
				for(k=j;k<ele;k++)
					a[k]=a[k+1];
				ele--;
			}
		}
		if(c==0)
			printf("%d ",a[i]);

	}
}*/
//method 2
/*#include<stdio.h>
main()
{
	int t,i,j,ele,c,b,a[]={0,3,1,0,5,1,2,0,4,5};
	ele=sizeof a/sizeof a[0];
	for(i=0;i<ele-1;i++)
	{
		for(j=0;j<ele-1-i;j++)
		{
			if(a[j]>a[j+1])
			{
				t=a[j];
				a[j]=a[j+1];
				a[j+1]=t;
			}
		}
	}
	for(i=0;i<ele;i=j)
	{
		c=1;
		for(j=i+1;j<ele;j++)
		{
			if(a[i]==a[j])
			{
				c++;
			}
			else
			break;
		}

		if(c==1)
			printf("%d\n",a[i]);
	}
}*/


//duplicate in one array remaining in another array
/*#include<stdio.h>
main()
{
	int a[]={10,2,4,5,2,1,3,4,6,5,8,9,2},b[10];
	int ele,i,j,k,l=0;
	ele=sizeof a/sizeof a[0];
	for(i=0;i<ele;i++)
	{
		for(j=i+1;j<ele;j++)
		{
			if(a[i]==a[j])
			{
				b[l++]=a[j];
				for(k=j;k<ele;k++)
					a[k]=a[k+1];
				ele--;
			}
		}
	}
for(i=0;i<ele;i++)
printf("%d ",a[i]);
printf("\n");
for(i=0;i<l;i++)
printf("%d ",b[i]);
printf("\n");
}*/



//sum of squares of numbers, and the squares series	
/*#include<stdio.h>
  main()
  {
  int n,i,r,s=0;
  printf("enter the number\n");
  scanf("%d",&n);
  int a[n];
  for(i=1;i<=n;i++)
  { 
  r=i*i;
  s+=r;
  a[i-1]=r;
  }
  printf("s=%d\n",s);
  for(i=0;i<n;i++)
  printf("%d ",a[i]);
  }*/

















