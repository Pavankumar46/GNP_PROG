//reversing the given string using ointers
#include<stdio.h>
void str_rev(char *);
main()
{
	char s[10];
	printf("enter the string\n");
	scanf("%s",s);
	str_rev(s);
	printf("%s",s);
}
void str_rev(char *p)
{
	char ch,*q;
	q=p;
	while(*q)
	q++;
	q--;
	while(p<q)
	{
		ch=*p;
		*p=*q;
		*q=ch;
		p++;
		q--;
	}
}
