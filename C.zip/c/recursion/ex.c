//sum of even numbers in an array using recursion
/*#include<stdio.h>
int sumeven(int *,int);
main()
{
	int ele,sum,a[]={8,7,6,4,1,2};
	ele=sizeof a/sizeof a[0];
	sum=sumeven(a,ele-1);
	printf("%d\n",sum);
	sum=sumeven(a,ele-1);
	printf("%d\n",sum);
}
int sumeven(int *p,int n)
{
	if(n>=0)
	{
		if(p[n]%2==0)

			return p[n]+sumeven(p,n-1);

		else
			return sumeven(p,n-1);
	}

	else
		return 0;
}*/

//bubble sort
/*#include<stdio.h>
void bubble(int *,int);
main()
{
	int n,i;
	printf("enter the number\n");
	scanf("%d",&n);
	int a[n];
	printf("enter the elements\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
	bubble(a,n);
	printf("after sorting\n");
	for(i=0;i<n;i++)
		printf("%d ",a[i]);
}
void bubble(int *p,int num)
{
	int j,i,t;
	j=num;
	if(j>0)
	{
		for(i=0;i<num-1;i++)
		{
			if(p[i]>p[i+1])
			{
				t=p[i];
				p[i]=p[i+1];
				p[i+1]=t;
			}
		}
		return bubble(p,num-1);
	}
	else
		return;
}*/

//minimum number using recursion
/*#include<stdio.h>
int min(int a[],int ,int);
main()
{
	int i,r,a[5],ele;
	ele=sizeof a/sizeof a[0];
	printf("enter the elements\n");
	for(i=0;i<ele;i++)
	{
		scanf("%d",&a[i]);
	}
	r=min(a,ele,a[0]);
	printf("min number is %d\n",r);
}
int min(int *p,int n,int m)
{
	if(n>0)
	{
		if(*p<m)
			m=*p;
		return min(p+1,n-1,m);
	}
	else
		return m;
}*/

//factorial using recursion
/*#include<stdio.h>
int fact(int);
main()
{
	int num,r;
	printf("enter the number\n");
	scanf("%d",&num);
	r=fact(num);
	printf("factorial of %d is %d\n",num,r);
}
int fact(int n)
{
	if(n)
	{
		return n*fact(n-1);
	}
	else
		return 1;
}*/

//gcd using recursion
//gcd of two numbers using recursion
/*#include<stdio.h>
int gcdfind(int ,int);
main()
{
	int a,b,gcd,lcm;
	printf("enter the numbers\n");
	scanf("%d%d",&a,&b);
	gcd=gcdfind(a,b);
	printf("gcd of %d & %d is %d\n",a,b,gcd);
	lcm=a*b/gcd;
	printf("lcm of %d & %d is %d\n",a,b,lcm);
}
int gcdfind(int n1,int n2)
{
	if(n2!=0)
		return gcdfind(n2,n1%n2);
	else
		return n1;
}*/

//fibonacci using recursion
/*#include<stdio.h>
int fib(int);
main()
{
	int n=0,c,count;
	printf("enter the n\n");
	scanf("%d",&count);
	for(c=0;c<count;c++)
	{
		printf("%d ",fib(n));
		n++;
	}
	printf("\n");
}
int fib(int n)
{
	if(n==0)
		return 0;
	else if(n==1)
		return 1;
	else 
		return (fib(n-1)+fib(n-2));
}*/

//sum of digits using recursion
/*#include<stdio.h>
int sumofdigits(int);
main()
{
	int r,num;
	printf("enter the number\n");
	scanf("%d",&num);
	r=sumofdigits(num);
	printf("sum of digits of %d is %d\n",num,r);
}
int sumofdigits(int n)
{
	if(n)
	{
		return n%10+sumofdigits(n/10);
	}
	else
		return 0;
}*/

//reversing a number using recursion
/*#include<stdio.h>
int reverse(int,int);
main()
{
	int r,num,s=0;
	printf("enter the number\n");
	scanf("%d",&num);
	r=reverse(num,s);
	printf("reverse of %d is %d\n",num,r);
	r=reverse(num,s);
	printf("reverse of %d is %d\n",num,r);
}
int reverse(int n,int s)
{
	int r;
	if(n)
	{
		r=n%10;
		s=s*10+r;
		return reverse(n/10,s);
	}
	else
		return s;

}*/

//lenght of a string using recursions
/*#include<stdio.h>
int length(const char *,int);
main()
{
	char s[]="gnpavan";int c=0,l;
	l=length(s,c);
	printf("lenght of %s is %d\n",s,l);
	l=length(s,c);
	printf("lenght of %s is %d\n",s,l);
}
int length(const char *p,int c)
{
	if(*p)
	{
		//		c++;
		//		return length(p+1,c);
		//			(or)
		return c+1+length(p+1,c);
	}
	else 
		//		return c;
		//		(or)
		return 0;
}*/

//binary printing of a number using recursion
/*#include<stdio.h>
void binary(int);
main()
{
	int num;
	printf("enter the number\n");
	scanf("%d",&num);
	binary(num);
	printf("\n");
	binary(num);
	printf("\n");
}
void binary(int n)
{
	static pos=31;
	if(pos>=0)
	{
		printf("%d",n>>pos&1);
		pos--;
		return binary(n);
	}
	else
		pos=31;
}*/

//printing the string char by char
/*#include<stdio.h>
void print(char *);
main()
{
	char s[100];
	printf("enter the string\n");
	scanf("%s",s);
	print(s);
	printf("\n");
}
void print(char *p)
{
	if(*p)
	{
		printf("%c ",*p);
		print(p+1);
	}
}*/

//reverse printing of a string
/*#include<stdio.h>
void print(char *);
main()
{
	char s[100];
	printf("enter the string\n");
	scanf("%s",s);
	print(s);
	printf("\n");
}
void print(char *p)
{
	if(*p)
	{
		print(p+1);
		printf("%c ",*p);
	}
}*/

//copying source string into destination string
/*#include<stdio.h>
void copy(char *,char *);
main()
{
	char s[100],d[100];
	printf("enter the s\n");
	scanf("%s",s);
	copy(s,d);
	printf("%s",d);
	printf("\n");
}
void copy(char *p,char *q)
{
	if(*p)
	{
		*q=*p;
		copy(p+1,q+1);
	}
	else
		*q='\0';
}*/
//power of a given number
/*#include<stdio.h>
int power(int ,int);
main()
{
	int a,b,r;
	printf("emter a and b\n");
	scanf("%d%d",&a,&b);
	r=power(a,b);
	printf("%d\n",r);
}
int power(int a,int n)
{
	if(n==0)
		return 1;
	else if(n%2==0)
		return power(a*a,n/2);
	else
		return a*power(a*a,(n-1)/2);
}*/

//display all proper divisors of a given number and their sum
/*#include<stdio.h>
int divisorsum(int,int );
main()
{
	int num,sum,t=1;
	printf("enter the number\n");
	scanf("%d",&num);
	sum=divisorsum(num,t);
	printf("\nsum of the divisors is %d\n",sum);
	sum=divisorsum(num,t);
	printf("\nsum of the divisors is %d\n",sum);
}
int divisorsum(int n,int t)
{
	if(t<n)
	{
		if(n%t==0)
		{
			printf("%d ",t);
			return t+divisorsum(n,t+1);
		} 
		else
			return divisorsum(n,t+1);
	}
	else
		return 0;
}*/


//prime numbers count=100
/*#include<stdio.h>
void prime(int,int);
main()
{
	int count,i;
	printf("enter the count\n");
	scanf("%d",&count);
	printf("enter the starting number\n");
	scanf("%d",&i);
	prime(count,i);
	printf("\n");
	prime(count,i);
	printf("\n");
}
void prime(int c,int n)
{
	int i;
	if(c)
	{
		for(i=2;i<n;i++)
		{
			if(n%i==0)
				break;
		}
		if(n==i)
		{
			printf("%d ",n);
			prime(c-1,n+1);
		}
		else
			prime(c,n+1);
	}
}*/

//palindrome numbers in a given number
/*#include<stdio.h>
void pal(int,int);
main()
{
	int num,i=0;
	printf("enter the number\n");
	scanf("%d",&num);
	pal(num,i);
	printf("\n");
}
void pal(int n,int i)
{
	int s,t;
	if(i<n)
	{
		t=i;
		for(s=0;t;t/=10)
			s=s*10+t%10;
		if(s==i)
			printf("%d ",s);
		pal(n,i+1);
	}
}*/

//palindrome for single number
/*#include<stdio.h>
int pal(int,int);
main()
{
	int num,b=0;
	printf("enter the number\n");
	scanf("%d",&num);
	if(num==pal(num,b))
		printf("palindrome nuber\n");
	else
		printf("not palindrome\n");
	printf("\n");
	if(num==pal(num,b))
		printf("palindrome nuber\n");
	else
		printf("not palindrome\n");
	printf("\n");
}
int pal(int n,int b)
{
	int a=0;
	if(n)
	{	a=n%10;
		b=b*10+a;		
		pal(n/10,b);
	}
	else
		return b;
}*/

//perfect number using recursion
/*#include<stdio.h>
int perfect(int);
main()
{
	int r,num;
	printf("enter the number\n");
	scanf("%d",&num);
	r=perfect(num);
	if(r==1)
		printf("perfect number\n");
	else
		printf("not perfect\n");
	r=perfect(num);
	if(r==1)
		printf("perfect number\n");
	else
		printf("not perfect\n");
}
int perfect(int n)
{
	static int i=1,s=0;
	if(i<n)
	{
		if(n%i==0)
		{
			s=s+i;
		}
			i++;
	perfect(n);
	}
	if(n==s)
		return 1;
	else
		return 0;
}*/


//binary printing of a number using recursion
/*#include<stdio.h>
void binary(int);
int reverse(int,int,int);
void reverseprint(int,int);
main()
{
	int num,r,i=0,j=31,pos=31;
	printf("enter the number\n");
	scanf("%d",&num);
	binary(num);
	printf("\n");
	r=reverse(num,i,j);
	printf("\n");
	reverseprint(pos,r);
	printf("\n");
//	binary(num);
//	printf("\n");
//	r=reverse(num,i,j);
//	printf("\n");
//	reverseprint(pos,r);
//	printf("\n");
}
void binary(int n)
{
	static pos=31;
	if(pos>=0)
	{
		printf("%d",n>>pos&1);
		pos--;
		return binary(n);
	}
	else
		pos=31;
}
int reverse(int n,int i,int j)
{
	int m,k;
	if(i<j)
	{
		m=n>>i&1;
		k=n>>j&1;
		if(m!=k)
		{
			n=n^1<<i;
			n=n^1<<j;
		}
		reverse(n,i+1,j-1);
	}
	else
		return n;
}
void reverseprint(int pos,int n)
{
	if(pos>=0)
	{
		printf("%d",n>>pos&1);
		reverseprint(pos-1,n);
	}
	else
	pos=31;
}*/

//reverse the elements of a given array
/*#include<stdio.h>
void arrreverse(int *,int,int);
main()
{
	int a[5],i,k=0,ele;
	ele=sizeof a/sizeof a[0];
	printf("enter the elements\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");
	arrreverse(a,ele-1,k);
	printf("after reversing\n");
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");
}
void arrreverse(int *p,int j,int i)
{
	int k,t;
	if(i<j)
	{
		t=p[i];
		p[i]=p[j];
		p[j]=t;
		arrreverse(p,j-1,i+1);
	}
}*/


//reverrse the string using recursion
#include<stdio.h>
void arrreverse(char *,int,int);
main()
{
	char a[10];int i,k=0,ele;
	printf("enter the string\n");
	scanf("%s",a);
	printf("%s",a);
	printf("\n");
	for(ele=0;a[ele];ele++);
	arrreverse(a,ele-1,k);
	printf("after reversing\n");
	printf("%s",a);
	printf("\n");
}
void arrreverse(char *p,int j,int i)
{
	int k,t;
	if(i<j)
	{
		t=p[i];
		p[i]=p[j];
		p[j]=t;
		arrreverse(p,j-1,i+1);
	}
		
}
