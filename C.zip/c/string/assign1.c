//string length using pointers


/*#include<stdio.h>
main()
{
char s[]="pavan";
char *p=s;
int i;
for(i=0;*p;i++,p++);
printf("%d",i);
}*/

//one line code to copy the string into another buffer
/*#include<stdio.h>
main()
{
char b[5],a[]="pavan";
char *p,*q;
q=a;
p=b;
while(*p++=*q++);
printf("%s",b);
}*/	


//no. of times the char found in a string
/*#include<stdio.h>
main()
{
int i,n,c=0;char ch;
printf("enter the no of char");
scanf("%d",&n);
char a[n];
printf("enter the string\n");
scanf("%s",a);
printf("enter the char\n");
scanf(" %c",&ch);
for(i=0;i<n;i++)
{
if(a[i]==ch)
 c++;
}
printf("%d",c);
}*/


//finding vowels in a sting
/*#include<stdio.h>
main()
{
char s[5];
int i;
printf("enter the string\n");
scanf("%s",s);
for(i=0;s[i];i++)
{
if(s[i]=='a'||s[i]=='e'||s[i]=='i'||s[i]=='o'||s[i]=='u'||s[i]=='A'||s[i]=='E'||s[i]=='I'||s[i]=='O'||s[i]=='U')
printf("%c ",s[i]);
}
printf("\n");
}*/

//comparing two strings without strcmp
/*#include<stdio.h>
main()
{
char a[10],b[10];
int i;
printf("enter the strings\n");
scanf("%s%s",a,b);
printf("%s %s\n",a,b);
for(i=0;a[i];i++)
if(a[i]!=b[i])
break;
if(a[i]==b[i])
printf("same\n");
else
printf("diff\n");
}*/


//reverse the sting using loops
/*#include<stdio.h>
main()
{
char temp,a[]="pavan";
int i,j;
for(j=0;a[j];j++);
for(i=0,j=j-1;i<j;i++,j--)
{
 temp=a[i];
 a[i]=a[j];
 a[j]=temp;
}
printf("%s\n",a);
}*/

//palindrome using string
/*#include<stdio.h>
main()
{
	char s[10],b[10],ch;
	int i,j;
	printf("enter the string\n");
	scanf("%s",s);
	for(i=0;s[i];i++)
		b[i]=s[i];
		b[i]=s[i];
	for(j=0;b[j];j++);
	for(i=0,j=j-1;i<j;i++,j--)
	{
		ch=b[i];
		b[i]=b[j];
		b[j]=ch;
	}
	printf("%s\n",b);
	for(i=0;s[i];i++)
	{
		if(s[i]!=b[i])
			break;
	} 
	if(s[i]==b[i])
		printf("palindrome\n");
	else
		printf("not palindrome\n");
}*/

//no. of words in a string
/*#include<stdio.h>
main()
{
char s[100];
int i,c=0,w=0,l=0;
printf("enter the string\n");
scanf("%[^\n]",s);
//printf("%s",s);
for(i=0;s[i];i++)
{
c++;
if(s[i]==' ')
w++;
}
l++;
printf("no. of char=%d, no. of word=%d, no, of lines=%d\n",c-w,w+1,l);
}*/

//delete a desired char in a string
/*#include<stdio.h>
main()
{
	char a[10],ch;
	int i,j;
	printf("enter the string\n");
	scanf("%s",a);
	printf("enter the char\n");
	scanf(" %c",&ch);
	for(i=0;a[i];i++)
	{
		if(a[i]==ch)
		{
			for(j=i;a[j];j++)
			{ 
				a[j]=a[j+1]; 
			}
			i--;
		}
	}
	printf("%s\n",a);
}*/

//remove the cojucutive place in a string
/*#include<stdio.h>
main()
{
char s[100],p[100];
int i,k=0;
printf("enter the string\n");
scanf("%[^\n]",s);
for(i=0;s[i];i++)
 {
  if(!(s[i]==' '&&s[i+1]==' '))
  {
	p[k]=s[i];
  	k++;
  }
}
p[k]='\0';
printf("%s",p);
}*/

//delete duplicate eliments
/*#include<stdio.h>
main()
{
	int i,c=0,m,j,k,l;
	char b[20],a[]="vecteeovvorr";
	for(l=0;a[l];l++);
	for(i=0;i<l;i++)
	{
		for(j=i+1;j<l;j++)
		{
			if(a[i]==a[j])
			{	
				if(a[i]==a[j+1])
				for(k=j;k<l;k++)
				a[k]=a[k+2];
				else
				for(k=j;k<l;k++)
				a[k]=a[k+1];
			l--;
			}
		}		
	}	
		for(i=0;i<k;i++)
		printf("%c",a[i]);
		printf("\n");
	
}*/

//counting the duplicata char
/*#include<stdio.h>
main()
{
	int l,i,j,k=0,c;
	char a[]="hrithik roshan",ch,b;
	for(l=0;a[l];l++);
	for(i=0;i<l;i++)
	{
		c=1;
		for(j=i+1;j<l;j++)
		{
			if(a[i]==a[j])
			{
			c++;
			for(k=j;k<l;k++)
			a[k]=a[k+1];
			l--;
			}
		}
		if(c>1)
		printf("%c %d\n",a[i],c);
	}
}*/




//count of lower case and upper case
/*#include<stdio.h>
main()
{
char a[100];
int i,s=0,l=0,u=0,n=0;
printf("enter the string\n");
scanf("%s",a);
for(i=0;a[i];i++)
{ 
if(a[i]>='a'&&a[i]<='z')
 l++;
 else if(a[i]>='A'&&a[i]<='Z')
 u++;
 else if(a[i]>='1'&&a[i]<='9')
 n++;
 else
 s++;
}
printf("lowercase count=%d, uppercase count=%d, special count=%d number count=%d\n",l,u,s,n);
}*/

//u to l and l to u
/*#include<stdio.h>
main()
{
char ch,s[10];
int i;
printf("enter the string\n");
scanf("%s",s);
for(i=0;s[i];i++)
{
if(s[i]>='a'&&s[i]<='z')
s[i]-=32;
else if(s[i]>='A'&&s[i]<='Z')
s[i]+=32;
}
printf("%s",s);
}*/

//sort a string in ascending order
/*#include<stdio.h>
main()
{
char a[100],ch;
int i,j,n;
printf("enter the string\n");
scanf("%s",a);
for(n=0;a[n];n++);
for(i=0;i<n;i++)
{
 for(j=i+1;j<n;j++)
  if(a[i]>a[j])
  {
        ch=a[i];
	a[i]=a[j];
	a[j]=ch;
  }
}
printf("%s\n",a);
}*/


//print two string char one by one
/*#include<stdio.h>
main()
{
	int i,j,k,l=0;
	char c[20],a[10],b[10];
	printf("enter the strings\n");
	scanf("%s%s",a,b);
	for(i=0;a[i];i++);
	for(j=0;b[j];j++);
	k=i+j;	
	for(i=0,j=0;k>0;i++,j++)
	{ 	
		if(a[i]!='\0')
		{
			c[l]=a[i];
			l++;	
			k--;	
		}
		if(b[j]!='\0')
		{
			c[l]=b[j];
			l++;
			k--;
		}
	}c[l]='\0';
	printf("%s\n",c);
}*/



//substring in a main string
/*#include<stdio.h>
main()
{
char a[100],b[100];
printf("enter the string\n");
scanf("%s",a);
printf("enter the substring\n");
scanf("%s",b);
int i,j,count,count1=0,l1,l2;
for(l1=0;a[l1];l1++);
for(l2=0;b[l2];l2++);
for(i=0;i<l1;)
{
 j=0;
 count=0;
  while(a[i]==b[j])
  {
   count++;
   j++;
   i++;
  }

  if(count==l2)
  {
   count1++;
   count=0;
  }
  else
   i++;
}
printf("%d\n",count1);
}*/

//method 1
//reverse the words in a string line
/*#include<stdio.h>
void str_rev1(char *,char *);
void str_rev(char *);
char *str_chr(char *,char);
main()
{	
	char s[]="i am a good boy",*p,*q;
	printf("%s\n",s);
	p=s;
	while(q=str_chr(p,' '))
	{
		str_rev1(p,q-1);
			p=q+1;
	}
	str_rev(p);
printf("%s\n",s);
}
char *str_chr(char *p,char q)
{
	while(*p)
	{
		if(*p==q)
		return p;
			p++;
	}
	return 0;
}
void str_rev1(char *p,char *q)
{
	char ch;
	while(p<q)
	{
		ch=*p;
		*p=*q;
		*q=ch;
		p++;
		q--;
	}
}
void str_rev(char *p)
{
	char *q,ch;

	q=p;
	while(*q)
		q++;
	q--;
	while(p<q)
	{
		ch=*p;
		*p=*q;
		*q=ch;
		p++;
		q--;
	}
}*/


//replace the words in reverse order
/*#include<stdio.h>
void str_rev1(char *,char *);
void str_rev(char *);
char *str_chr(char *,char);
main()
{	
	char s[]="world changed your thoughts",*p,*q;
	printf("%s\n",s);
	p=s;
	str_rev(p);
	while(q=str_chr(p,' '))
	{
		str_rev1(p,q-1);
			p=q+1;
	}
	str_rev(p);
printf("%s\n",s);
}
char *str_chr(char *p,char q)
{
	while(*p)
	{
		if(*p==q)
		return p;
			p++;
	}
	return 0;
}
void str_rev1(char *p,char *q)
{
	char ch;
	while(p<q)
	{
		ch=*p;
		*p=*q;
		*q=ch;
		p++;
		q--;
	}
}
void str_rev(char *p)
{
	char *q,ch;
	q=p;
	while(*q)
		q++;
	q--;
	while(p<q)
	{
		ch=*p;
		*p=*q;
		*q=ch;
		p++;
		q--;
	}
}*/

//method 2
//replace the words in reverse order in a given string line
/*#include<stdio.h>
main()
{
	char s[100];
	printf("enter the string\n");
	scanf("%[^\n]s",s);
	int l,i;
	for(l=0;s[l];l++);
	for(i=l-1;i>=0;i--)
	{
		if(s[i]==' ')
		{
			s[i]='\0';
			printf("%s ",&s[i]+1);
		}
	}
	printf("%s",s);
	printf("\n");
}*/

//Replacing a word in a string with another string
/*#include<stdio.h>
#include<string.h>
void replacesubstring(char [],char[],char[]);
main()
{
	char string[100],sub[100],new[100];
	printf("enter the string\n");
	gets(string);
	printf("enter the sub string\n");
	gets(sub);
	printf("enter the new string\n");
	gets(new);
	replacesubstring(string,sub,new);
	printf("the string after replacing\n");
	puts(string);
	printf("\n");
}
void replacesubstring(char string[],char sub[],char new[])
{
	int stringl,subl,newl;
	int i=0,j,k;
	int flag=0,start,end;
	stringl=strlen(string);
	subl=strlen(sub);
	newl=strlen(new);
	for(i=0;i<stringl;i++)
	{
		flag=0;
		start=i;
		for(j=0;string[i]==sub[j];j++,i++) //searching the string
			if(j==subl-1)
				flag=1;
		end=i;
		if(flag==0)
			i=i-j;
		else
		{
			for(j=start;j<end;j++)  //deleting the string
			{
				for(k=start;k<stringl;k++)
					string[k]=string[k+1];
				stringl--;
				i--;
			}
			for(j=start;j<start+newl;j++)  //inserting the string
			{
				for(k=stringl;k>=j;k--)
					string[k+1]=string[k];
				string[j]=new[j-start];
				stringl++;
				i++;
			}
		}
	}
}*/

//anagram
/*#include<stdio.h>
void str_ing(char *);
int anag(char *,char *);
main()
{
	char s1[100],s2[100];int r,s;
	printf("enter the s1\n");
	scanf("%s",s1);
	printf("enter the s2\n");
	scanf("%s",s2);
	str_ing(s1);
	printf("%s\n",s1);
	str_ing(s2);
	printf("%s\n",s2);
	r=anag(s1,s2);
	s=anag(s2,s1);
	if(r==s)
	printf("anagram\n");
	else
	printf("not anagram\n");
}
void str_ing(char *p)
{
	int i;
	for(i=0;p[i];i++)
		if(p[i]>='a'&&p[i]<='z')
			p[i]-=32;
}
int anag(char *s1,char *s2)
{
	int i,j,c;
	char r;
	for(i=0;s1[i];i++)
	{
		if(s1[i]>='A'&&s1[i]<='Z')
		{
			r=s1[i];
			c=0;
			for(j=0;s1[j];j++)
			{
				if(s1[j]==r)
					c++;
			}
			for(j=0;s2[j];j++)
			{
				if(s2[j]==r)
					c--;
			}
			if(c!=0)
			{
				return 0;
				break;
			}
		}
	}
	if(c==0)
return 1;
}*/


//decryption and encryption
/*#include<stdio.h>
void str_rev(char *,char *);
void decrypt(char *,int);
main()
{
	char s[100];
	printf("enter the string\n");
	scanf("%[^\n]",s);
	int key;
	printf("enter the key\n");
	scanf(" %d",&key);
	printf("%s\n",s);
	decrypt(s,key);
	printf("%s\n",s);

}
void str_rev(char *p,char *q)
{
	char ch;
	ch=*p;
	*p=*q;
	*q=ch;
}
void decrypt(char *s,int key)
{
	int i,j=0;
	for(i=0;s[i];i++)
	{
		if((s[i]>='a'&&s[i]<='z')||(s[i]>='A'&&s[i]<='Z'))
		{
			j++;
			if(j%key==0)
			{
				if(*(s+i+1)=='\0')
				goto L1;
				if(*(s+i)==' ')
					str_rev(s+i+1,s+i+1);
				if(*(s+i+1)==' ')
					str_rev(s+i,s+i+1+1);
				else
					str_rev(s+i,s+i+1);
				L1:;
			}
		}
	}
}*/
