#include<stdio.h>
main()
{
	char t,a[100],b[]="Expcet Porblmes adn eat thef mor rbeafkast";
	int i,n,j=0,l,k,c=0,m;
	for(l=0;b[l];l++);
	for(i=0;b[i];i++)
		a[i]=b[i];
	for(i=0;i<l;i++)
	{
		if(a[i]==' ')
		{
			for(k=i;k<l;k++)
				a[k]=a[k+1];
			l--;
		}
	}
	for(i=3;i<l;i+=4)
	{
		t=a[i];
		a[i]=a[i+1];
		a[i+1]=t;
	}
	for(m=0;a[m];m++);
	for(i=l-1;i>=0;i--)
	{
	c++;
		if(b[i]==' ')
		{
			for(j=m-1;j>=0;j--)
				if(j==m-1-c+2)
				{
					for(n=m-1;n>=j;n--)
						a[n+1]=a[n];
					a[n]=' ';
					c++;
				}}
			for(m=0;a[m];m++);
		
	}

	printf("%s",a);
	printf("\n");
}











