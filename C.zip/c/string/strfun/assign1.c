//find string length using pointer
/*#include<stdio.h>
int length(char *);
main()
{
	char s[10];int l;
	printf("enter the num\n");
	scanf("%s",s);
	l=length(s);
	printf("%d\n",l);
}
int length(char *p)
{
	int c=0;
	while(*p++)
		c++;
	return c;
}*/

//one line code to copy the string 
/*#include<stdio.h>
void copy(char *,char *);
main()
{
	char a[10],b[10];
	printf("enter the string\n");
	scanf("%s",a);
	copy(a,b);
	printf("%s\n",b);
}
void copy(char *p,char *q)
{
	int i;
	while(*q++=*p++);
}*/

//no. of times char is found
/*#include<stdio.h>
int times(const char *,char);
main()
{
	char s[10],c,ch;
	printf("enter the string\n");
	scanf("%s",s);
	printf("enter the char\n");
	scanf(" %c",&ch);
	c=times(s,ch);
	printf("%d\n",c);
}
int times(const char *p,char ch)
{
	int c=0;
	while(*p++)
		if(*p==ch)
			c++;
	return c;
}*/

//vowels in a string
/*#include<stdio.h>
void vowels(char *);
main()
{
	char s[10];
	printf("enter the string\n");
	scanf("%s",s);
	vowels(s);
	printf("\n");
}
void vowels(char *p)
{
	while(*p++)
		if(*p=='a'||*p=='e'||*p=='i'||*p=='o'||*p=='u'||*p=='A'||*p=='E'||*p=='I'||*p=='O'||*p=='U')
			printf("%c ",*p);
}*/

//compare two strings without string function
/*#include<stdio.h>
int compare(char *,char *);
main()
{
	char a[10],b[10];int r;
	printf("enter the first string");
	scanf("%s",a);
	printf("enter the second string");
	scanf("%s",b);
	printf("%s\n",a);
	printf("%s\n",b);
	printf("-----------------------------\n");
	r=compare(a,b);
	if(r==1)
		printf("same\n");
	else
		printf("diff\n");
}
int compare(char *p,char *q)
{
	int i;
	for(i=0;p[i];i++)
		if(p[i]!=q[i])
			break;
	if(p[i]==q[i])
		return 1;
	else
		return 0;
}*/

//reverse the string using loops
/*#include<stdio.h>
void reverse(char *);
main()
{
	char s[10];
	printf("enter the string\n");
	scanf("%s",s);
	reverse(s);
	printf("%s",s);
	printf("\n");
}
void reverse(char *p)
{
	char *q=p,ch;
	while(*q)
		q++;
	q--;
	while(p<q)
	{
		ch=*p;
		*p=*q;
		*q=ch;
		p++;q--;
	}
}*/

//reverse the string using recursion
/*#include<stdio.h>
void arrreverse(char *,int,int);
main()
{
	char a[10];int i,k=0,ele;
	printf("enter the string\n");
	scanf("%s",a);
	printf("%s",a);
	printf("\n");
	for(ele=0;a[ele];ele++);
	arrreverse(a,ele-1,k);
	printf("after reversing\n");
	printf("%s",a);
	printf("\n");
}
void arrreverse(char *p,int j,int i)
{
	int k,t;char ch;
	if(i<j)
	{
		ch=*(p+i);
		*(p+i)=*(p+j);
		*(p+j)=ch;
		arrreverse(p,j-1,i+1);
	}
}*/


//palindrome
/*#include<stdio.h>
int pal(char *);
main()
{
	char r,s[10];
	printf("enter the umber\n");
	scanf("%s",s);
	r=pal(s);
	if(r==1)
		printf("pal\n");
	else
		printf("not pal\n");
}
int pal(char *p)
{
	char *q;
	q=p;
	while(*q)
		q++;
	q--;
	while(p<q)
		if(*p++==*q--)
			break;
	if(*p==*q)
		return 1;
	else
		return 0;
}*/


//finding no. of words in a strings 
/*#include<stdio.h>
int find(char *,char);
main()
{
	char s[100];int r;
	printf("enter the string\n");
	scanf("%[^\n]",s);
	r=find(s,' ');
	printf("%d\n",r);
}
int find(char *p,char ch)
{
	int c=0;
	while(*p)
	{
		if(*p==ch)
			c++;
		p++;
	}
	return c+1;
}*/


//delete a desired char
/*#include<stdio.h>
int words(char *,char );
main()
{
	char s[10],ch;int i;
	printf("enter the string\n");
	scanf("%s",s);
	printf("enter the char\n");
	scanf(" %c",&ch);
	for(i=0;s[i];i++);
	words(s,ch);
	printf("%s\n",s);
}
int words(char *p,char ch)
{
	int i,j;
	for(i=0;p[i];i++)
	{
		if(p[i]==ch)
		{
			for(j=i;p[j];j++)
				p[j]=p[j+1];
			i--;
		}

	}
}*/

//method 1------------------------------------------doubt
//program to remove conjugate places----------------doubt
/*#include<stdio.h>
void places(char *,char *);
main()
{
	char s[100],b[100];
	printf("enter the string\n");
	scanf("%[^\n]",s);
	//	printf("%s",s);
	places(s,b);
	printf("%s\n",b);
}
void places(char *p,char *q)
{
	
	while(*p)
	{
		if(*p==' ')
		p++;
		else
		break;
	}
	while(*p)
	{	
		*q=*p;
		p++;
		q++;
	}
	while(*q)
	q--;
	while(*q)
	{
		if((*q==' ')&&(*(q+1)==' '))
		{	while(*q)
			{
				*(q+1)=*(q+2);
				q++;
			}
			q--;
		}q++;
	}
*q='\0';
}*/

//method 2
//program to remove conjugate places
/*#include<stdio.h>
void place(char *,char *);
main()
{
	char a[100],b[100];
	printf("enter the string\n");
	scanf("%[^\n]",a);
	place(a,b);
	printf("%s\n",b);
}
void place(char *p,char *q)
{
	int i,j,s,k,m,l;
	for(l=0;p[l];l++);
	for(s=0;p[s]==' ';s++);
	for(k=0,m=s;m<l;k++,m++)
		q[k]=p[m];
	q[k]='\0';
	for(i=0;q[i];i++)
	{
		if(q[i]==' '&&q[i+1]==' ')
		{
			for(j=i+1;q[j];j++)
				q[j]=q[j+1];
			i--;
		}
	}
}*/

//delete duplicate elements
/*#include<stdio.h>
void del(char *);
main()
{
	char a[100];
	printf("enter the string\n");
	scanf("%s",a);
	del(a);
	printf("%s\n",a);
}
void del(char *p)
{
	int k,i,j;
	for(i=0;p[i];i++)
	{
		for(j=i+1;p[j];j++)
		{
			if(p[i]==p[j])
			{
				for(k=j;p[k];k++)
					p[k]=p[k+1];
				j--;
			}
		}
	}
}*/

//count of duplicate characters
/*#include<stdio.h>
void coudup(char *);
main()
{
	char a[100];
	printf("enter the string\n");
	scanf("%[^\n]",a);
	coudup(a);
}
void coudup(char *p)
{
	int i,j,k,c;
	for(i=0;p[i];i++)
	{
		c=1;
		for(j=i+1;p[j];j++)
		{
			if(p[i]==p[j])
			{
				c++;
				for(k=j;p[k];k++)
					p[k]=p[k+1];
				j--;
			}
		}
	if(c>1)
	printf("%c--%d\n",p[i],c);
}
}*/

//count of lower, upper & digits in a string
/*#include<stdio.h>
void count(char *);
main()
{
	char a[100];
	printf("enter the string\n");
	scanf("%s",a);
	count(a);
}
void count(char *p)
{
	int i,j,k,c=0,q=0,r=0,s=0;
	for(i=0;p[i];i++)
	{
		if(p[i]>='A'&&p[i]<='Z')
			c++;
		else if(p[i]>='a'&&p[i]<='z')
			q++;
		else if(p[i]>='0'&&p[i]<='9')
			r++;
		else
			s++;
	}
	printf("upper=%d, lower=%d, digits=%d, char=%d\n",c,q,r,s);
}*/

//l to u & u to l
/*#include<stdio.h>
void lower(char *,char,char);
void upper(char *,char,char);
main()
{
	char s[100];
	printf("enter the string\n");
	scanf("%s",s);
	lower(s,'a','z');
	printf("%s\n",s);
	upper(s,'A','Z');
	printf("%s\n",s);
}
void lower(char *p,char ch,char ch1)
{
	int i;
	while(*p)
	{
		if(*p>=ch&&*p<=ch1)
			*p-=32;
		p++;
	}
}
void upper(char *p,char ch,char ch1)
{
	int i;
	while(*p)
	{
		if(*p>=ch&&*p<=ch1)
			*p+=32;
		p++;
	}
}*/

//sort in ascending order
/*#include<stdio.h>
void sort(char *,int);
main()
{
	char a[100];int i;
	printf("enter the string\n");
	scanf("%s",a);
	for(i=0;a[i];i++);
		sort(a,i);
	printf("%s\n",a);
}
void sort(char *p,int l)
{
	int i,j;char t;
	for(i=0;i<l;i++)
	{
		for(j=0;j<l-1-i;j++)
		{
			if(p[j]>p[j+1])
			{
				t=p[j];
				p[j]=p[j+1];
				p[j+1]=t;
			}
		}
	}
}*/

//two strings print one by one
/*#include<stdio.h>
void ono(char *,char *,char *,int );
main()
{
	char a[10],b[10],c[20];int i,m,d;
	printf("enter first strings\n");
	scanf("%s%s",a,b);
	printf("%s\n",a);
	printf("%s\n",b);
	for(i=0;a[i];i++);
	for(m=0;b[m];m++);
	d=i+m;
	ono(a,b,c,d);
}
void ono(char *a,char *b,char *c,int k)
{int l=0,i,j;
	
	for(i=0,j=0;k>0;i++,j++)
	{
		if(a[i]!='\0')
		{
			c[l]=a[i];
			l++;
			k--;
		}
		if(b[j]!='\0')
		{
			c[l]=b[j];
			l++;
			k--;
		}
		c[l]='\0';
	}
	printf("%s\n",c);
}*/
//substring in a main string
/*#include<stdio.h>
void sub(char *,char *,int,int);
main()
{
	char a[100],b[50];int i,j;
	printf("enter the string\n");
	scanf("%[^\n]",a);
	for(i=0;a[i];i++);
	printf("enter the sub string\n");
	scanf("%s",b);
	for(j=0;b[j];j++);
	sub(a,b,i,j);
}
void sub(char *p,char *q,int i,int j)
{
	int k=0,l;
	int count,count1=0;
	for(k=0;k<i;)
	{
		l=0;
		count=0;
		while(p[k]==q[l])
		{
			count++;
			k++;
			l++;
		}
		if(count==j)
		{
			count1++;
			count=0;
		}
		else
			k++;
	}
	printf("%d\n",count1);
}*/

//reverse the words in a given string line
/*#include<stdio.h>
char *str_chr(char *,char);
void str_rev1(char *,char *);
void str_rev(char *);
main()
{
	char a[50],*p,*q;
	printf("enter the string\n");
	scanf("%[^\n]",a);
	p=a;
	while(q=str_chr(p,' '))
	{
		str_rev1(p,q-1);
		p=q+1;
	}
	str_rev(p);
	printf("%s\n",a);
}
char *str_chr(char *p,char q)
{
	while(*p)
	{
		if(*p==q)
			return p;
		p++;
	}
	return 0;
}
void str_rev1(char *p,char *q)
{
	char ch;
	while(p<q)
	{
		ch=*p;
		*p=*q;
		*q=ch;
		p++;
		q--;
	}
}
void str_rev(char *p)
{
	char *q,ch;
	q=p;
	while(*q)
		q++;
	q--;
	while(p<q)
	{
		ch=*p;
		*p=*q;
		*q=ch;
		p++;
		q--;
	}
}*/


//replace words in reverse order
/*#include<stdio.h>
char *str_chr(char *,char);
void str_rev1(char *,char *);
void str_rev(char *);
main()
{
	char a[50],*p,*q;
	printf("enter the string\n");
	scanf("%[^\n]",a);
	p=a;
	str_rev(p);
	while(q=str_chr(p,' '))
	{
		str_rev1(p,q-1);
		p=q+1;
	}
	str_rev(p);
	printf("%s\n",a);
}
char *str_chr(char *p,char q)
{
	while(*p)
	{
		if(*p==q)
			return p;
		p++;
	}
	return 0;
}
void str_rev1(char *p,char *q)
{
	char ch;
	while(p<q)
	{
		ch=*p;
		*p=*q;
		*q=ch;
		p++;
		q--;
	}
}
void str_rev(char *p)
{
	char *q,ch;
	q=p;
	while(*q)
		q++;
	q--;
	while(p<q)
	{
		ch=*p;
		*p=*q;
		*q=ch;
		p++;
		q--;
	}
}*/


//replace a word in a sting using another string
/*#include<stdio.h>
#include<string.h>
void replace(char [],char [],char []);
main()
{
	char a[50],b[50],c[50];
	printf("enter the string\n");
	gets(a);
	printf("enter the sub\n");
	gets(b);
	printf("enter the new\n");
	gets(c);
	replace(a,b,c);
	printf("after replacing\n");
	puts(a);
	printf("\n");
	}
void replace(char str[],char sub[],char new[])
{
	int i,j,k,start,end,flag=0,strl,subl,newl;
	strl=strlen(str);
	subl=strlen(sub);
	newl=strlen(new);
	for(i=0;i<strl;i++)
	{
		flag=0;
		start=i;
		for(j=0;str[i]==sub[j];j++,i++)
			if(j==subl-1)
				flag=1;
		end=i;
		if(flag==0)
			i=i-j;
		else
		{
			for(j=start;j<end;j++)
			{
				for(k=start;k<strl;k++)
					str[k]=str[k+1];
				strl--;
				i--;
			}
			for(j=start;j<start+newl;j++)
			{
				for(k=strl;k>=j;k--)
					str[k+1]=str[k];
				str[j]=new[j-start];
				strl++;
				i++;
			}
		}
	}
}*/


//anagram
/*#include<stdio.h>
int anag(char *,char *);
void upper(char *);
main()
{
	char a[50],b[50];int r,s;
	printf("enter the stiring\n");
	scanf("%[^\n]",a);
	printf("%s\n",a);
	printf("enter the stiring\n");
	scanf(" %[^\n]",b);
	printf("%s\n",b);
	upper(a);
	upper(b);
	r=anag(a,b);
	s=anag(b,a);
	if(r==s)
		printf("anagram\n");
	else
		printf("not anagram\n");
}
void upper(char *p)
{
	int i;
	for(i=0;p[i];i++)
		if(p[i]>='a'&&p[i]<='z')
			p[i]-=32;
}
int anag(char *p,char *q)
{
	int c,i,j,r;
	for(i=0;p[i];i++)
	{
		if(p[i]>='A'&&p[i]<='Z')
		{
			c=0;
			r=p[i];		
			for(j=0;p[j];j++)
				if(p[j]==r)
					c++;
			for(j=0;q[j];j++)
				if(q[j]==r)
					c--;
			if(c!=0)
			{
			return 0;
			break;
			}
		}
	}
if(c==0)
return 1;
}*/

//decrypt and encrypt
/*#include<stdio.h>
void str_rev1(char *,char *);
void decrypt(char *,int);
main()
{
	char a[100];int n;
	printf("enter the string\n");
	scanf("%[^\n]",a);
	printf("enter the number\n");
	scanf(" %d",&n);
	decrypt(a,n);
	printf("%s\n",a);
}
void str_rev1(char *p,char *q)
{
	char ch;
	while(p<q)
	{
		ch=*p;
		*p=*q;
		*q=ch;
		p++;
		q--;
	}
}
void decrypt(char *s,int ele)
{
int i,j;
	for(i=0;s[i];i++)
	{
		if((s[i]>='a'&&s[i]<='z')||(s[i]>='A'&&s[i]<='Z'))
			j++;
		if(j%ele==0)
		{
			if(*(s+i+1)=='\0')
			goto L1;
			else if(*(s+i)==' ')
			str_rev1(s+i,s+i);
			else if(*(s+i+1)==' ')
			str_rev1(s+i,s+i+1+1);
			else
			str_rev1(s+i,s+i+1);
			L1:;
		}
	}
}*/


