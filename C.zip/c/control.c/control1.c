//factorial
/*#include<stdio.h>
main()
{
int i,r=1,n;
printf("enter the number\n");
scanf("%d",&n);
for(i=1;i<=n;i++)
{
 r=r*i;
}
printf("%d is the factorial of %d\n",r,n);
}*/


//sum of digits
/*#include<stdio.h>
main()
{
int s,i,n;
printf("enter the number\n");
scanf("%d",&n);
for(s=0;n!=0;n/=10)
{
s=s+n%10;
}
printf("%d is the sum of the digits of the %d\n",s,n);
}*/


//reversing the digit
/*#include<stdio.h>
main()
{
int i,n,s;
printf("enter the number\n");
scanf("%d",&n);
for(s=0;n!=0;n/=10)
{
s=s*10+n%10;
}
printf("%d\n",s);
}*/


//lower case to upper case & vice versa
/*#include<stdio.h>
main()
{
char i,ch;
printf("enter the character\n");
scanf("%c",&ch);
if(ch>=97 && ch<=122)
ch=ch-32;
else
ch=ch+32;

printf("%c",ch);
}*/


//multiplication from 10 to 20
/*#include<stdio.h>
main()
{
int i,j,n,n1;
printf("enter starting and ending table number\n");
scanf("%d %d",&n,&n1);
for(i=n;i<=n1;i++)
{
 for(j=1;j<=10;j++)
  {
   printf("%d*%d=%d \n",i,j,i*j);
  }
printf("\n");
}
printf("\n");
}*/


// first 100 prime numbers
/*#include<stdio.h>
main()
{
int n,i,j,c=0;
printf("enter how many prime numbers needed\n");
scanf("%d",&n);
for(j=1;c<=n;j++)
{
for(i=2;i<j;i++)
{
if(j%i==0)
break;
}
if(j==i)
{
printf("%d ",j);
c++;
}
}
}*/


//armstrong number
#include<stdio.h>
main()
{
	int c,r,i,p,l,n,k,s;
	printf("enter upto which number\n");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		p=i;
		for(c=0;p!=0;c++)
		{
			p=p/10;
		}
		p=i;
		for(s=0;p!=0;p/=10)
		{
			r=p%10;
			for(l=1,k=1;l<=c;l++)
			{
				k=k*r;
			}
			s=s+k;
		}
		if(s==i)
			printf("%d\t",s);
	}
} 


//binary of a given number
/*#include<stdio.h>
main()
{
	int pos,n;
	printf("enter the number");
	scanf("%d",&n);
	for(pos=31;pos>=0;pos--)
	{
		printf("%d",n>>pos&1);
	}
}*/


//reverse the bit of a given number
/*#include<stdio.h>
main()
{
	int m,k,i,j,n,pos;
	printf("enter the number");
	scanf("%d",&n);
	for(pos=31;pos>=0;pos--)
	{
		printf("%d",n>>pos&1);
	}
	printf("\n");
	for(i=0,j=31;i<j;i++,j--)
	{
		m=n>>i&1;
		k=n>>j&1;
		if(m!=k)
		{
			n=n^(1<<i);
			n=n^(1<<j);
		}
	}
	for(pos=31;pos>=0;pos--)
	{
		printf("%d",n>>pos&1);
	}
	printf("\n");
}*/
 

//calculatro using switch
/*#include<stdio.h>
main()
{
int a,b,c,n;
printf("enter the a and b\n");
scanf("%d %d",&a,&b);
printf("1.add, 2.sub, 3.mul, 4.div\n");
scanf("%d",&n);
switch(n)
 {
 case 1: printf("%d+%d=%d\n",a,b,a+b);
	break; 
case 2: printf("%d-%d=%d\n",a,b,a-b);
	break; 
case 3: printf("%d*%d=%d\n",a,b,a*b);
	break;
 case 4: printf("%d% %d=%d\n",a,b,a%b);
 	break;
default : printf("wrong option\n"); 
}
}*/


//complement of a given number
/*#include<stdio.h>
main()
{
int n,pos;
printf("enter the given number");
scanf("%d",&n);
for(pos=31;pos>=0;pos--)
{
printf("%d",n>>pos&1);
}
printf("\n");
n=~n;
for(pos=31;pos>=0;pos--)
{
printf("%d",n>>pos&1);
}
printf("\n");
}*/


//2's complement of a given number
/*#include<stdio.h>
  main()
  {
  int n,pos;
  printf("enter the given number");
  scanf("%d",&n);
  for(pos=31;pos>=0;pos--)
  {
  printf("%d",n>>pos&1);
  }
  printf("\n");
  n=~n+1;
  for(pos=31;pos>=0;pos--)
  {
  printf("%d",n>>pos&1);
  }
  printf("\n");
  }*/


//power of a given number
/*#include<stdio.h>
main()
{
	int i,k=1,n,p,q;
	printf("enter the number and power\n");
	scanf("%d %d",&n,&p);
	for(i=1;i<=p;i++)
	{
		k=k*n;
	}
	printf("%d",k);
	printf("\n");
}*/


//complement of a particular bit
/*#include<stdio.h>
main()
{
	int pos,n,k;
	printf("enter the number\n");
	scanf("%d %d",&n,&k);
	for(pos=31;pos>=0;pos--)
	{
		printf("%d",n>>pos&1);
	}
	printf("\n");
	for(pos=31;pos>=0;pos--)
	{
		if(pos==k)
		{
			n=n^(1<<pos);
		}
		printf("%d",n>>pos&1);
	}
}*/


//palindrome series
/*#include<stdio.h>
main()
{
int k,s,i,j,n;
printf("enter the number\n");
scanf("%d",&n);
for(i=1;i<=n;i++)
{
k=i;
for(s=0,j=k;k!=0;k/=10)
{
s=s*10+k%10;
}
if(s==i)
printf("%d ",s);
}
printf("\n");
}*/


//fibonacci series
/*#include<stdio.h>
main()
{
	int n,i,a=0,b=1,c;
	printf("enter the number\n");
	scanf("%d",&n);
	printf("%d %d ",a,b);
	for(i=1;i;i++)
	{
		c=a+b;
		a=b;
		b=c;
		if(c<=n)
			printf("%d ",c);
		else
			break;
	}
	printf("\n");
}*/


//power of 2
/*#include<stdio.h>
main()
{
	int n,r;
	printf("enter the number\n");
	scanf("%d",&n);
	r=n&n-1;
	if(r==0)
		printf("%d is the power of 2\n",n);
	else
		printf("%d is not the power of 2 \n",n);
}*/


//biggest number 
/*#include<stdio.h>
main()
{
	int a,b,c;
	printf("enter the values of a,b &c\n");
	scanf("%d %d %d",&a,&b,&c);
	if(a>b)
	{
		if(a>c)
			printf("%d is big\n",a);
		else
			printf("%d is big\n",c);
	}
	else
		if(b>c)
			printf("%d is big\n",b);
		else
			printf("%d is big\n",c);
}*/
/*#include<stdio.h>
main()
{
	int a,b,c;
	printf("enter the values of a,b &c\n");
        scanf("%d %d %d",&a,&b,&c);
        a>b?a>c?printf("%d is big\n",a):printf("%d is big\n",c):b>c?printf("%d is big\n",b):printf("%d is big\n",c);
}*/
  

//calender
/*#include<stdio.h>
main()
{
	int n;
	printf("enter the month number from 1 to 12\n");
	scanf("%d",&n);
	switch(n)
	{
		case 1: printf("jan\n");break;   
		case 2: printf("fab\n");break;
		case 3: printf("mar\n");break;   
		case 4: printf("apr\n");break;   
		case 5: printf("may\n");break;
		case 6: printf("june\n");break;
		case 7: printf("july\n");break;  
		case 8: printf("august\n");break;   
		case 9: printf("sepy\n");break;   
		case 10: printf("oct\n");break;   
		case 11: printf("nov\n");break;   
		case 12: printf("dec\n");break;   
		default:printf("number exceeded\n");
	}
}*/


//perfect number series
/*#include<stdio.h>
main()
{
int n,q,s,i,j;
printf("enter the number\n");
scanf("%d",&n);
for(i=1;i<=n;i++)
{
q=i;
s=0;
 for(j=1;j<q;j++)
 {
  if(q%j==0)
  s+=j;
 }
if(s==i)
 printf("%d ",s);
}
printf("\n");
}*/


//strong number
/*#include<stdio.h>
main()
{
int n1,n,j,s,k,r=1;
printf("enter the number\n");
scanf("%d",&n1);
n=n1;
for(s=0;n>0;n/=10)
{
 r=n%10;
  for(j=r-1;j>0;j--)
  r=r*j;
s+=r;
}
if(s==n1)
printf("%d is strong number\n",n1);
else
printf("%d is not strong number\n",n1);
}*/
