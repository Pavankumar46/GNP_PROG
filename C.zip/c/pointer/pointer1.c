//p9.1
/*#include<stdio.h>
int main(void)
{
	int age=30;
	float salary=1500.50;
	printf("Address of age=%p\n",&age);
	printf("Address of salary=%p\n",&salary);
	return 0;
}*/

//p9.2
/*#include<stdio.h>
int main(void)
{
	int a=87;
	float b=4.5;
	int *p1=&a;
	float *p2=&b;
	printf("Value of p1 = Address of a = %p\n",p1);
	printf("Value of p2 = Address of b = %p\n",p2);
	printf("Address of p1 = %p\n",&p1);
	printf("Address of p2 = %p\n",&p2);
	printf("Value of a = %d  %d  %d\n",a,*p1,*(&a));
	printf("Value of b = %.1f  %.1f  %.1f\n",b,*p2,*(&b));
	return 0;
}*/

//p9.3
/*#include<stdio.h>
int main(void)
{
	char a='x',*p1=&a;
	int b=12,*p2=&b;
	float c=12.4,*p3=&c;
	double d=18.34,*p4=&d;
	printf("sizeof(p1)=%u, sizeof(*p1)=%u\n",sizeof(p1),sizeof(*p1));
	printf("sizeof(p2)=%u, sizeof(*p2)=%u\n",sizeof(p2),sizeof(*p2));
	printf("sizeof(p3)=%u, sizeof(*p3)=%u\n",sizeof(p3),sizeof(*p3));
	printf("sizeof(p4)=%u, sizeof(*p4)=%u\n",sizeof(p4),sizeof(*p4));
	return 0;
}*/

//p9.4
/*#include<stdio.h>
int main(void)
{
	int a=5,*pi=&a;
	char b='x',*pc=&b;
	float c=5.5,*pf=&c;
	printf("Value of pi=Address of a=%p\n",pi);
	printf("Value of pc=Address of b=%p\n",pc);
	printf("Value of pf=Address of c=%p\n",pf);
	pi++;
	pc++;
	pf++;
	printf("Now value of pi=%p\n",pi);
	printf("Now value of pc=%p\n",pc);
	printf("Now value of pf=%p\n",pf);
	return 0;
}*/

//p9.5
/*#include<stdio.h>
int main(void)
{
	int a=5;
	int *p;
	p = &a;
	printf("Value of p = Address of a = %p\n",p);
	printf("Value of p = %p\n",++p);
	printf("Value of p = %p\n",p++);
	printf("Value of p = %p\n",p);
	printf("Value of p = %p\n",--p);
	printf("Value of p = %p\n",p--);
	printf("Value of p = %p\n",p);
	return 0;
}*/

//p9.6
/*#include<stdio.h>
int main(void)
{
	int a=5;
	int *pa;
	int **ppa;
	pa = &a;
	ppa = &pa;
	printf("Address of a=%p\n",&a);
	printf("Value of pa=Address of a=%p\n",pa);
	printf("Value of *pa=Value of a=%d\n",*pa);
	printf("Address of pa=%p\n",&pa);
	printf("Value of ppa=Address of pa=%p\n",ppa);
	printf("Value of *ppa=Value of pa=%p\n",*ppa);
	printf("Value of **ppa=Value of a=%d\n",**ppa);
	printf("Address of ppa=%p\n",&ppa);
	return 0;
}*/

/*P9.7 Program to print the value and address of the elements of an array */
/*#include<stdio.h>
int main(void)
{
	int arr[5] = {5,10,15,20,25};
	int i;
	for(i=0; i<5; i++)
	{
		printf("Value of arr[%d] = %d\t",i,arr[i]);
		printf("Address of arr[%d] = %p\n",i,&arr[i]);
	}
	return 0;
}*/

/*P9.8 Program to print the value and address of elements of an array using pointer notation*/
/*#include<stdio.h>
int main(void)
{
	int arr[5]={5,10,15,20,25};
	int i;
	for(i=0; i<5; i++)
	{
		printf("Value of arr[%d] = %d\t",i,*(arr+i));
		printf("Address of arr[%d] = %p\n",i,arr+i);
	}
	return 0;
}*/

/* P9.9 Program to print the value of array elements using pointer and subscript notation */
/*#include<stdio.h>
int main(void)
{
	int arr[5] = {5,10,15,20,25};
	int i=0;
	for(i=0; i<5; i++)
	{
		printf("Value of arr[%d] = ",i);
		printf("%d\t",arr[i]);
		printf("%d\t",*(arr+i));
		printf("%d\t",*(i+arr));
		printf("%d\n",i[arr]);
		printf("Address of arr[%d] = %p\n",i,&arr[i]);
	}
	return 0;
}*/

/*P9.10 Program to print the value and address of array elements by subscripting a pointer variable*/
/*#include<stdio.h>
int main(void)
{
	int arr[5]={5,10,15,20,25};
	int i,*p;
	p=arr;		
	for(i=0; i<5; i++)
	{
		printf("Address of arr[%d]= %p %p %p %p\n",i,&arr[i],arr+i,p+i,&p[i]);
		printf("Value of arr[%d]= %d %d %d %d\n",i,arr[i],*(arr+i),*(p+i),p[i]);
	}
	return 0;
}*/

/*P9.11 Program to understand difference between pointer to an integer and pointer to an array of integers*/
/*#include<stdio.h>
int main(void)
{
	int *p;		// Can point to an integer
	int (*ptr)[5];  // Can point to an array of 5 integers
	int arr[5];
	p=arr;	        //Points to 0th element of arr
	ptr=&arr;	//Points to the whole array arr
	printf("p=%p,ptr=%u\n",p,ptr);
	p++;
	ptr++;
	printf("p=%p,ptr=%u\n",p,ptr);
	return 0;
}*/
/*P9.12 Program to dereference a pointer to an array*/
/*#include<stdio.h>
int main(void)
{
	int arr[5] = {3,5,6,7,9};
	int *p=arr;
	int (*ptr)[5]=&arr;

	printf("p=%p, ptr=%p\n",p,ptr);
	printf("*p=%d, *ptr=%p\n",*p,*ptr);
	printf("sizeof(p)=%u,sizeof(*p)=%u\n",sizeof(p),sizeof(*p));
	printf("sizeof(ptr)=%u,sizeof(*ptr)=%u\n",sizeof(ptr),sizeof(*ptr));
	return 0;
}*/

/*P9.13 Program to print the values and address of elements of a 2-D array*/
/*#include<stdio.h>
int main(void)
{
	int arr[3][4]= {
		{10,11,12,13}, 
		{20,21,22,23}, 
		{30,31,32,33}
	};
	int i,j;
	for(i=0; i<3; i++)
	{
		printf("Address of %dth array = %p %u\n",i,arr[i],*(arr+i));
		for(j=0; j<4; j++)
			printf("%d %d ",arr[i][j],*(*(arr+i)+j));
		printf("\n");
	}
	return 0;
}*/


/*P9.14 Program to print elements of a 2-D array by subscripting a pointer to an array variable*/
/*#include<stdio.h>
int main(void)
{
	int arr[3][4] = { {10,11,12,13}, {20,21,22,23}, {30,31,32,33} };
	int (*ptr)[4];
	ptr = arr;
	printf("%p   %p  %p\n",ptr,ptr+1,ptr+2);
	printf("%p   %p  %p\n",*ptr,*(ptr+1),*(ptr+2));
	printf("%d  %d   %d\n",**ptr,*(*(ptr+1)+2),*(*(ptr+2)+3));
	printf("%d  %d   %d\n",ptr[0][0],ptr[1][2],ptr[2][3]);
	return 0;
}*/

/*P9.15 Program to print the elements of 3-D array using pointer notation*/
#include<stdio.h>
int main(void)
{
	int arr[2][3][2] = {
		{
			{5,10}, 
			{6,11}, 
			{7,12}, 
		}, 
		{
			{20,30}, 
			{21,31}, 
			{22,32}, 
		}
	};
	int i,j,k;
	for(i=0; i<2; i++)
		for(j=0; j<3; j++)
		{
			for(k=0; k<2; k++)
				printf("%d\t",*(*(*(arr+i)+j)+k));
			printf("\n");
		}
	return 0;
}

