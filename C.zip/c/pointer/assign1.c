//1
/*#include<stdio.h>     
int main()     
{ 
int *p = 10; 
printf("%u\n",(unsigned int)p); 
//printf("%d\n",*p);     
}*/	//warning
	//10

//2
/*#include<stdio.h>
main()
{
int *p,a=10;
p=&a;
*p+=1;
printf("%d %d\n",*p,a);
}*/        // 11 11

//3
/*#include<stdio.h>
main()
{
int x=-300;
unsigned char *p;
p=&x;
printf("%d\n",*p++);
printf("%d\n",*p);
}*/        //212
	   //254->unexpected

//4
/*#include<stdio.h>      
int main()      
{ 
int x = 256; 
char *p = &x; 
printf("%u ",p);
*++p = 2; 
printf("%d %u",x,p);      
}*/
         //512

//5)  
/*#include<stdio.h>     
int main()      
{
int x = 300; 
if(*(char *)&x == 44) 
printf("Little Endian\n"); 
else 
printf("Big Endian\n");     
}*/   //little endian

 
//6)     
/*#include <stdio.h>        
void main()        
{            
int x = 0;            
int *ptr = &5;            
printf("%p\n", ptr);        
}*/	 //l value required


//7)  
/*#include<stdio.h>     
int main()     
{ 
int const *p = 5; 
int q; 
p = &q; 
printf("%d",++(*p));      
}*/	//we can't change *p


//8)  
/*#include<stdio.h>     
int main()     
{ 
int x = 10; 
int const * const p; 
p = &x; 
printf("%d\n", *p);     
}*/ 	//can't change *p
 
// 9)  
/*#include <stdio.h>        
int x = 0;        
void main()        
{            
int *const ptr = &x;            
printf("%p\n", ptr);            
ptr++;            
printf("%p\n ", ptr);        
}*/	//can't change ptr


// 10) 
/*#include <stdio.h>        
int main()         
{            
const int ary[4] = {1, 2, 3, 4};            
int *p;            
p = ary + 3;            
*p = 5;            
printf("%d\n", ary[3]);        
}*/	//5


//  11) 
/*#include <stdio.h>        
int main()        
{            
int ary[4] = {1, 2, 3, 4};            
int *p = ary + 3;            
printf("%d\n", p[-2]);    
}*/	//2


// 12)  
/*#include <stdio.h>        
void main()        
{            
char *s= "hello";            
char *p = s + 2;            
printf("%c\t%c", *p, s[1]);        
}*/	//l	e


// 13) 
/*#include <stdio.h>        
int main()        
{            
void *p;            
int a[4] = {1, 2, 3, 4};            
p = &a[3];            
int *ptr = &a[2];            
int n = (int*)p - ptr;            
printf("%d\n", n);        
}*/	//1


//14) 
/*#include<stdio.h>      
int main()      
{ 
int a[ ] = {10,20,30,40,50},i; 
char *p = a;
for(i=0;i<5;i++)           
printf("%d   ",*p++);      
}*/	//10 0 0 0 20


//15)  
/*#include<stdio.h>       
int main()        
{ 
int a[]={10,20,30,40,50}; 
char *p; 
p=(char *)a; 
printf("%d\n",*((int *)p+4));        
}*/	//50

 
//16) 
/*#include <stdio.h>        
int main()        
{            
double *ptr = (double *)100;            
ptr = ptr + 2;            
printf("%u\n", ptr);        
}*/	//116

 
//  17)  
/*#include <stdio.h>          
int main()          
{              
int i = 10;
void *p = &i;                     
 printf("%d\n", *(int*)p);            
return 0;        
}*/	//warning
	//10


//18)   
/*#include <stdio.h>        
int main()        
{            
int a[4] = {1, 2, 3, 4};            
void  *p = &a[1];            
void *ptr = &a[2];            
int n = 1;            
n =ptr - p;            
printf("%d\n", n);        
}*/	//4----gives address value


// 19) 
/*#include <stdio.h>       
int main()        
{            
int *p = (int *)2;            
int *q = (int *)3;            
printf("%d", p + q);        
}*/	// error=invalid operand (+), only  (-)  can be used 


// 20) Which of the following operand can be applied to pointers p and q?       (Assuming initialization as 
/*int *a = (int *)2; 
int *b = (int *)3;) 
a)  a + b b) a – b c) a * b d) a / b        Ans: b)*/
 

/*21) Which of following logical operation can be applied to pointers?       (Assuming initialization 
int *a = 2; 
int *b = 3;) 
a) a | b b) a ^ b c) a & b d) None of the mentioned
*/      //Ans: d)
  
// 22) 
/*#include <stdio.h>        
void main()        
{            
char *s = "hello";            
char *n = "cjn";            
/char *p = s + n;            
printf("%c\t%c",*p, s[1]);        
}*/	//addition can't be donr

 // 23) 
/*#include <stdio.h>        
void m(int *p)        
{            
int i = 0;            
for(i = 0;i < 5; i++)            
printf("%d\t", p[i]);        
}        
void main()        
{            
int a[5] = {6, 5, 3};            
m(&a);        
}*/	//6 5 3 0 0 

// 24)
/*#include <stdio.h>        
void foo(int*);        
int main()        
{            
int i = 10,j=20,*p = &i;            
foo(p++);    
foo(p);        
}        
void foo(int *p)        
{            
printf("%d\n", *p);        
}*/	// 10
	// 20
 

//25)
/*#include <stdio.h>        
int main()        
{            
int i = 97, *p = &i;            
foo(&i);            
printf("%d ", *p);        
}        
void foo(int *p)        
{            
int j = 2;            
p = &j;            
printf("%d ", *p);        
}*/	//2 97


//26)  
/*#include<stdio.h>       
int main()       
{ 
const int ary[4] = {1,2,3,4}; 
int *p = ary+3; 
*p = 5; 
ary[3] = 6; 
printf("%d",ary[3]);     
}*/	//array can't be changed


//27)  
/*#include<stdio.h>       
int main()
{
char *p = "Hai friends",*p1 = p; 
while(*p!='\0'); 
++*p++; 
printf("%s  %s\n",p,p1);
}*/	//it doesn't come out of the loop


//28)  
/*#include<stdio.h>       
int main()       
{ 
char *x ="VECTOR"; 
printf("%s\n",x+3); 
//printf(“%d\n”+1,123456);    //it gives error 
}*/	//TOR


//29)  
/*#include<stdio.h>       
int main()       
{ 
char a[ ]="abcdefgh"; 
int *ptr=a;
printf("%d %d\n",ptr[0],ptr[1]);       
}*/	//replace int with char


//30)
/*#include<stdio.h>          
#include<string.h>        
int main()        
{            
char *str = "hello, world\n";            
char *strc = "good morning\n";            
strcpy(strc, str);            
printf("%s\n", strc);            
return 0;        
}*/		//segmentation fault
 
//31)
/*#include <stdio.h>        
int main()        
{            
char *str = "hello world";            
char strc[50] = "good morning india\n";            
strcpy(strc, str);            
printf("%s\n", strc);            
return 0;        
}*/	//hello world




//  32) 
/*#include <stdio.h>        
int main()        
{            
char *str = "hello, world\n";            
str[5] = '.';            
printf("%s\n", str);
return 0;        
}*/	//segmantation fault


// 33) 
/*#include <stdio.h>        
int main()        
{            
char str[] = "hello, world";            
str[5] = '.';            
printf("%s\n", str);            
return 0;        
}*/	//hello. world

// 34) 
/*#include <stdio.h>        
int main()        
{            
char *str = "hello world";            
char strary[] = "hello world";            
printf("%d %d\n", sizeof(str), sizeof(strary));            
return 0;        
}*/	//4 12


// 35) 
/*#include <stdio.h>        
int main()        
{            
char *str = "hello world";            
char strary[] = "hello world";            
printf("%d %d\n", strlen(str), strlen(strary));            
return 0;        
}*/	//11 11


// 36)  
/*#include<stdio.h>       
int main()        
{ 
int a = 5,b = 4,c = 9; 
*(a>b ? &a : &b) = (a+b)>c; 
printf("%d  %d\n",a,b);       
}*/	//0 4


//37)  Find the sizeof any datatype with out using sizeof operator. (Hint : Use pointers)
/*#include<stdio.h>
main()
{
char *p=0;
p++;
printf("%d\n",p);
}*/

//38)  
/*#include<stdio.h>        
int main()        
{ 
int i; 
double a = 5.2; 
char *ptr; 
ptr = (char *)&a; 
for(i=0;i<=7;i++) 
printf("%d\n",*ptr++); 
return 0;        
}*/  //-51 -52 -52 -52 -52 -52 20 64


//39)  Correct the following program.           
/*#include<stdio.h> 
int main() 
{ 
void *p;                        
int  **ptr;                        
int a = 129; 
p = &a;                        
ptr = &p; 
printf(" p = %d   p = %u  &p = %u\n", *p, p,&p);           
}*/	//replace void with int, we can assign any data type to void, we can't assign void to any data type


//40) 
/*#include<stdio.h>       
main()       
{ 
char a[20]; 
char *p,*q; 
p=&a[0]; 
q=&a[10]; 
printf("%d %p %p %d\n",q-p,&q,&p,&q-&p);       
}*/	//10 1094 1090 1






