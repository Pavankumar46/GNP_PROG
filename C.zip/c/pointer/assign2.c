//41)
/*#include<stdio.h>        
main()        
{                
int a=0x12345678;     
void *ptr;     
ptr=&a;     
printf("0x%x\n",*(int *)&*(char*)ptr);        
}*/	//0x12345678


//42) 
/*#include<stdio.h>       
main()       
{ 
int a[5]={1,2,3,4,5}; 
int *ptr=(int *)(&a+1); 
printf("%d %d\n",*(a+1),*(ptr-1)); 
printf("%d %d\n",*(a+1),*(ptr));       
}*/	//2  5
	//2  garbage value


// 43) 
/*#include <stdio.h>         
void main()         
{            
char *s= "hello";            
char *p = s;            
printf("%c\t%c", 1[p], s[1]);         
}*/	//e	e


//44) 
/*#include<stdio.h>       
main()       
{
char a[]="abcde"; 
char *p=a; 
p++; 
p++; 
p[2]='z'; 
printf("%s",p);
}*/


//45)      
/*#include<stdio.h>            
main() 
{ 
char a[]="ABCDEFGHIJKLMNOPQRSTUVWXYZ";                       
int i,*p=a;                       
for(i=0;i<5;i++)                       
printf("%d\t",*p++); 
} */	// char can't convert to int, garbage values
	// 1145258561	1212630597	1280002633	1347374669	1414746705        

//46)     
/*#include<stdio.h>              
main()  
{ 
char *ptr = "abcdef"; 
ptr1 = ptr1+(strlen(ptr1)-1); 
printf("%c", --*ptr1--); 
printf("%c",--*--ptr1); 
printf("%c",--*(ptr1--)); 
printf("%c",--*(--ptr1)); 
printf("%c",*ptr1); 
}*///warning and error
           
//47) 
/*#include<stdio.h> 
int main() 
{ 
char *str1 = "Hello"; 
char *str2 = "Hai"; 
char *str3; 
str3 = strcat(str1,str2); 
printf("%s  %s\n",str3,str1); 
return 0; 
}*/	//segmentation fault


//  48) 
/*#include<stdio.h> 
int main() 
{ 
char a[]="Hello"; 
char *p="Hai"; 
a="Hai"; 
p="Hello"; 
printf("%s  %s\n",a,p); 
return 0; 
}*/	//error=we can't change array string


//  49)     
/*#include<stdio.h> 
#include<string.h>
int main() 
{ 
int i,n; 
char *x="Alice"; 
n=strlen(x); 
*x=x[n]; 
for(i=0;i<=n;i++) 
{ 
printf("%s",x); 
x++; 
} 
printf("%s\n",x); 
return 0; 
}*/	//segmentation fault


//50)    
/*#include<stdio.h> 
char *str=char *str=%c%s%c;
main()
{
printf("str,34,str,34");
} 						//doubt
int main() 
{ 
printf(str,34,str,34); 
return 0; 
}*/	

//51)   
/*#include <stdio.h>        
void f(char *k)        
{            
k++;            
k[2] = 'm';            
printf("%c\n", *k);        
}        
void main()        
{            
char s[] = "hello";            
f(s);            
printf("%s\n",s);        
}*/	//e 	helmo


// 52)  
/*#include<stdio.h>        
void t1(char *q);        
main()        
{ 
char *p; 
p = "abcder"; 
t1(p);        
}        
void t1(char *q)        
{ 
if(*q!='r') 
{ 
putchar(*q); 
t1(q++);
}
}*/	//infinite loop


//53) 
/*#include<stdio.h>       
int main()
{       
int i;       
float a=5.2;       
char *ptr;       
ptr=(char *)&a;       
for(i=0;i<=3;i++)       
printf("%d ",*ptr++);       
return 0;       
}*/	//102 102 -90 64


// 54) 
/*#include <stdio.h>        
void foo( int[] );        
int main()        
{            
int ary[4] = {1, 2, 3, 4};            
foo(ary);            
printf("%d ", ary[0]);        
}        
void foo(int p[4])        
{            
int i = 10;            
p = &i;            
printf("%d ", p[0]);        
}*/	//10 1


// 55) 
/*#include <stdio.h>        
void main()        
{            
int k = 5;            
int *p = &k;            
int **m  = &p;             
**m = 10;            
printf("%d %d %d\n", k, *p, **m);        
}*/	//10 10 10


// 56) 
/*#include <stdio.h>        
int main()        
{            
int a = 1, b = 2, c = 3;            
int *ptr1 = &a, *ptr2 = &b, *ptr3 = &c;            
int **sptr = &ptr1;     
printf("%d  ",**sptr);            
*sptr = ptr2;    
printf("%d  ",**sptr);        
}*/	//1	2


// 57) 
/*#include <stdio.h>        
void main()        
{            
int a[3] = {1, 2, 3};            
int *p = a;            
int **r = &p;            
printf("%d\n", (**r));        
}*/	//1


//58)  
/*#include <stdio.h>        
int main()        
{            
int i = 97, *p = &i;            
foo(&p);            
printf("%d ", *p);            
return 0;        
}        
void foo(int **p)        
{            
int j = 2;            
*p = &j;            
printf("%d ", **p);        
}*/	//2 2

// 59) 
/*#include <stdio.h>        
void foo(int *const *p);        
int main()        
{            
int i = 11;            
int *p = &i;            
foo(&p);            
printf("%d ", *p);        
}        
void foo(int *const *p)        
{            
int j = 10;            
*p = &j;            
printf("%d ", **p);        
}*/	//it can only read


//60)   
/*#include <stdio.h>        
void foo(int **const p);        
int main()        
{            
int i = 10;            
int *p = &i;            
foo(&p);            
printf("%d ", *p);        
}        
void foo(int **const p)        
{            
int j = 11;
*p = &j;            
printf("%d ", **p);        
}*/ 	//11 11

//61)   
/*#include <stdio.h>        
int *f();        
int main()        
{             
int *p = f();             
printf("%d\n", *p);        
}         
int *f()        
{              
int *j = (int*)malloc(sizeof(int));            
*j = 10;             
return j;        
}*/	//10


// 62)  
/*#include <stdio.h>        
void main()        
{            
char *a[10] = {"hi", "hello", "how"};            
int i = 0;            
for (i = 0;i < 10; i++)            
printf("%s  ", *(a[i]));        
}*/	//segmentation fault,  to get answer remove star in printf
 
// 63) 
/*#include <stdio.h>        
void main()        
{            
char *a[10] = {"hi", "hello", "how"};            
int i = 0, j = 0;            
a[0] = "hey";            
for (i = 0;i < 10; i++)            
printf("%s  ", a[i]);        
}*/   //hey  hello  how  (null)  (null)  (null)  (null)  (null)  (null)  (null)

// 64) 
/*#include <stdio.h>        
void main()        
{            
char *a[10] = {"hi", "hello", "how"};            
printf("%d\n", sizeof(a));        
}*/	//40

 
// 65) 
/*#include <stdio.h>        
void main()        
{            
char *a[10] = {"hi", "hello", "how"};            
printf("%d\n", sizeof(a[1]));        
}*/	//4


// 66) 
/*#include <stdio.h>        
int main()        
{            
char a[2][6] = {"hello", "hi"};            
printf("%s  ", *a + 1);            
return 0;        
}*/	//ello

//67)  
/*#include <stdio.h>        
int main()        
{            
char *a[2] = {"hello", "hi"};            
printf("%s\n", *(a + 1));            
return 0;        
}*/	//hi


// 68) 
/*#include <stdio.h>        
int main(int argc, char *argv[])        
{            
while (argc--)            
printf("%s\n", argv[argc]);            
return 0;        
}*/	//./a.out


// 69) 
/*#include <stdio.h>        
int main(int argc, char *argv[])        
{            
while (*argv++ != NULL)            
printf("%s\n", *argv);            
return 0;        
}*/	//segnmentation fault

// 70) 
/*#include <stdio.h>        
int main(int argc, char *argv[])        
{            
while (*argv  !=  NULL)            
printf("%s\n", *(argv++));
return 0;        
}*/	//./a.out
	//pavan


//71) 
/*#include<stdio.h> 
int main(int sizeof argv, char *argv[]) 
{ 
while(sizeof argv) 					//doubt
printf("%s  ",argv[--sizeof argv]); 
return 0; 
} */ //if i/p is   sample  friday tuesday sunday
	 

//72) 
/*#include<stdio.h> 
int main() 
{
char *str[]={"Progs","Do","Not","Die","They","Croak!"}; 
printf("%d  %d",sizeof(str),strlen(str[0])); 
return 0;
}*/ 	//24 5


//73) 
/*#include<stdio.h> 
int main() 
{ 
static char *s[]={"black","white","pink","violet"}; 
char **ptr[]={s+3,s+2,s+1,s},***p; 
p = ptr; 
printf("%s\n",**p+1); 
return 0; 
}*/	//iolet


//74) 
/*#include<stdio.h> 
main() 
{ 
char *m[]={"jan","feb","mar"}; 
char d[][10] = {"sun","mon","tue"}; 
printf("%s\t",m[1]); 
printf("%s\t",d[1]); 
}*/	//feb	mon


//75) 
/*#include<stdio.h> 
void fun(char **); 
int main() 
{ 
char *argv[]={"ab","cd","ef","gh"}; 
fun(argv); 
return 0; 
} 
void fun(char **p) 
{ 
char *t; 
t=(p+=sizeof(int))[-1]; 
printf("%s\n",t); 
}*/	//gh			//doubt

//76)   
/*#include <stdio.h>        
void first()        
{            
printf("first");        
}        
void second()        
{            
first();        
}        
void third()        
{            
second();        
}
void main()        
{            
void (*ptr)();            
ptr = third;            
ptr();        
}*/	//first

//77) 
/*#include <stdio.h>        
int add(int a, int b)        
{            
return a + b;        
}        
int main()        
{            
int (*fn_ptr)(int, int);            
fn_ptr = add;            
printf("The sum of two numbers is: %d\n", (int)fn_ptr(2, 3));        
}*/	//5


//78) 
/*#include <stdio.h>        
int mul(int a, int b, int c)        
{            
return a * b * c;        
}        
void main()        
{            
int (*function_pointer)(int, int, int);            
function_pointer  =  mul;            
printf("The product of three numbers is:%d",            
function_pointer(2, 3, 4));        
}*/	//24

// 79)      
/*#include<stdio.h> 
int fun(int (*)()); 
int main() 
{ 
fun(main); 
printf("Hi\n"); 
return 0; 
} 
int fun(int (*p)()) 
{ 
printf("Hello\n"); 
return 0; 
}*/	//hello
	//hi


//80)    
/*#include<stdio.h>        
int main()          
{ 
char *p = "Hello World"; 
printf(p); 
}*/	//hello world










