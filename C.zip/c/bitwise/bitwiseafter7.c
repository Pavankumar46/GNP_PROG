//U to L and vice versa
/*#include<stdio.h>
main()
{
	char ch;
	printf("enter the char\n");
	scanf("%c",&ch);
	if(ch>='a'&&ch<='b')
	{
		ch=ch&~32;
		printf("%c",ch);
	}else
	{
		ch=ch|32;
		printf("%c",ch);
	}
}*/


//compare two numbers
/*#include<stdio.h>
main()
{
int i,j;
printf("enter the number\n");
scanf("%d %d",&i,&j);
i^j?printf("diff\n"):printf("same\n");
}*/


//float binary formation
#include<stdio.h>
main()
{
float num;
char *c=&num;
int i,j;
printf("enter the number\n");
scanf("%f",&num);
c=c+3;
for(i=1;i<=4;i++)
{
 for(j=7;j>=0;j--)
 {
 printf("%d",(*c)>>j&1);
}
printf(" ");
c--;
}
printf("\n");
}


//swaping adjacent bytes 
/*#include<stdio.h>
main()
{
unsigned int x=0x1234;
printf("%x\n",x);
x=((x<<8)&0xff00)|((x>>8)&0x00ff);
printf("%x\n",x);
}*/

/*#include<stdio.h>
main()
{
unsigned char ch=0x34;
printf("%x\n",ch);
ch=(ch<<4)|(ch>>4);
printf("%x\n",ch);
}*/


//swapping first and last nibbles
/*#include<stdio.h>
main()
{
int i,j,m,k,pos,n;
printf("enter the number\n");
scanf("%d",&n);
for(pos=31;pos>=0;pos--)
printf("%d",n>>pos&1);
printf("\n");
for(i=0,j=28;i<=4||j<=31;i++,j++)
{
  m=n>>i&1;
  k=n>>j&1;
  if(m!=k)
{
  n=n^1<<i;
  n=n^1<<j;
}
}
for(pos=31;pos>=0;pos--)
printf("%d",n>>pos&1);
}*/


//extracting p bits
/*#include<stdio.h>
main()
{
	int p,b,n,k;
	printf("enter the number\n");
	scanf("%d",&n);
	for(p=31;p>=0;p--)
		printf("%d",n>>p&1);
	printf("\n");
	printf("enter the position and bits\n");
	scanf("%d %d",&p,&b);
	k=(((1<<b)-1)&(n>>(p-1)));
	printf("%d\n",k);
	for(p=31;p>=0;p--)
		printf("%d",k>>p&1);
	printf("\n");
}*/


//clearing a particular bit
/*#include<stdio.h>
main()
{
	int pos,l,n,k;
	printf("enter the number and position");
	scanf("%d %d",&n,&k);
	for(pos=31;pos>=0;pos--)
		printf("%d",n>>pos&1);
	printf("\n");
	for(pos=31;pos>=0;pos--)
	{
		if(pos==k)
{
		l=n&~(1<<pos);
			printf("%d",l>>pos&1);
}		else
			printf("%d",n>>pos&1);
	}
	printf("\n");
}*/ 

